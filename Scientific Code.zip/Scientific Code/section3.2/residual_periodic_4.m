function F = residual_periodic_4(Q, D, A, C)
    N = size(A,1) - 1;
    Q_mat = reshape(Q, 4, [])';
    dQ = reshape(D*Q, 4, [])';
    
    % q_dot = q*a*q + c
    qa = qmult_vec_4(Q_mat, A);
    qaq = qmult_vec_4(qa, Q_mat);
    
    Res_mat = dQ - (qaq + C);
    F = reshape(Res_mat', [], 1);
    
    % Periodic boundary condition: q(0) - q(T) = 0
    % Replace the last row of equations
    row = 4*N+1 : 4*(N+1);
    F(row) = Q(1:4) - Q(end-3:end);
end