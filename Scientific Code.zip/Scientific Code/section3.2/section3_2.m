clear; clc; close all;

% --- 0. Global Settings ---
colors.source = [0.850, 0.325, 0.098]; % Red
colors.sink   = [0.00, 0.447, 0.741]; % Blue
colors.het    = [0.466, 0.674, 0.188]; % Green
set(0, 'DefaultTextInterpreter', 'latex');
set(0, 'DefaultAxesFontSize', 14);

%% --- 1. System Definition ---
T_per = 2*pi;

% Coefficient construction: q_dot = q * a(t) * q + c(t)
a_fun = @(t) [-0.5*ones(size(t)), cos(t), 0.3*sin(t), zeros(size(t))];
c_fun = @(t) [-0.1*ones(size(t)), zeros(size(t)), zeros(size(t)), 0.2*cos(2*t)];

% ODE function handle 
rhs_ode = @(t, q) riccati_rhs_val_4(t, q, a_fun, c_fun);

%% --- 2. Compute Boundary Periodic Orbits ---
fprintf('Step 1: Computing Boundary Orbits (Robust Mode)...\n');

N_orb = 30; 
[x_orb, D_orb] = cheb_4(N_orb);
t_orb = (x_orb + 1) * T_per / 2;
D_glob_orb = kron(D_orb * (2/T_per), eye(4));

% Compute coefficients at nodes
A_orb = a_fun(t_orb);
C_orb = c_fun(t_orb);

% --- 2.1 Find Sink (Stable Orbit) ---
fprintf('  > Solving Sink Orbit...\n');
q0_guess = [0.1; 0; 0; 0]; 
[~, traj_sink] = ode45(rhs_ode, [0, 50*T_per], q0_guess); 
q_sink_init = traj_sink(end, :); 
[~, q_sink_nodes] = ode45(rhs_ode, t_orb, q_sink_init);
Q_guess_sink = reshape(q_sink_nodes', [], 1);

% Solve using fsolve 
[Q_sink, flag1] = solve_periodic_fsolve_4(Q_guess_sink, D_glob_orb, A_orb, C_orb);
if flag1 <= 0, warning('Sink orbit fsolve did not fully converge'); end

% --- 2.2 Find Source (Unstable Orbit) ---
fprintf('  > Solving Source Orbit...\n');
q0_guess_src = [2; 2; 2; 2]; 
[~, traj_src] = ode45(rhs_ode, [0, -50*T_per], q0_guess_src); 
q_src_init = traj_src(end, :);
[~, q_src_nodes] = ode45(rhs_ode, t_orb, q_src_init);
Q_guess_src = reshape(q_src_nodes', [], 1);

[Q_source, flag2] = solve_periodic_fsolve_4(Q_guess_src, D_glob_orb, A_orb, C_orb);
if flag2 <= 0, warning('Source orbit fsolve did not fully converge'); end

fprintf('   -> Sink Norm: %.4f\n', norm(Q_sink(1:4)));
fprintf('   -> Source Norm: %.4f\n', norm(Q_source(1:4)));

%% --- 3. Solve Heteroclinic Orbit (Robust Continuation Method) ---
fprintf('Step 2: Solving Heteroclinic Connection via Continuation...\n');

T_list = [1.5, 2.0, 2.5, 3.0] * T_per; 
Q_het_curr = [];
T_curr = T_list(1); 

for k = 1:length(T_list)
    T_curr = T_list(k);
    fprintf('  > Continuation Step %d: T = %.2f pi\n', k, T_curr/pi);
    
    N_curr = 60 + k*20; 
    [x_curr, D_curr] = cheb_4(N_curr);
    t_curr = (x_curr + 1) * T_curr / 2;
    D_glob_curr = kron(D_curr * (2/T_curr), eye(4));
    
    if k == 1
        sigmoid = @(t) 1 ./ (1 + exp(-2 * (t - T_curr/2))); 
        w = sigmoid(t_curr);
        t_mod = mod(t_curr, T_per);
        q_src_i = bary_interp_vector_4(reshape(Q_source, 4, [])', t_orb, t_mod);
        q_snk_i = bary_interp_vector_4(reshape(Q_sink, 4, [])',   t_orb, t_mod);
        q_guess = (1-w) .* q_src_i + w .* q_snk_i;
        Q_guess = reshape(q_guess', [], 1);
    else
        q_prev = reshape(Q_het_curr, 4, [])';
        q_guess = bary_interp_vector_4(q_prev, linspace(0,1,size(q_prev,1))', linspace(0,1,N_curr+1)');
        Q_guess = reshape(q_guess', [], 1);
    end
    
    t_start_mod = mod(0, T_per);
    t_end_mod = mod(T_curr, T_per);
    bc_s = bary_interp_vector_4(reshape(Q_source, 4, [])', t_orb, t_start_mod);
    bc_e = bary_interp_vector_4(reshape(Q_sink, 4, [])',   t_orb, t_end_mod);
    
    options = optimoptions('fsolve', 'Display', 'iter', 'FunctionTolerance', 1e-6, ...
        'MaxFunctionEvaluations', 50000, 'MaxIterations', 100);
    
    fun = @(x) residual_bvp_wrapper_4(x, D_glob_curr, t_curr, a_fun, c_fun, bc_s, bc_e);
    [Q_het_curr, ~, flag] = fsolve(fun, Q_guess, options);
    
    if flag <= 0
        warning('Continuation step failed. Trying to proceed...');
    end
end

Q_het = Q_het_curr;
t_het = t_curr; 
T_total = T_curr; 

fprintf('Heteroclinic connection computed.\n');

%% --- 4. Advanced Visualization ---
fprintf('Step 3: Rendering...\n');

q_src = reshape(Q_source, 4, [])';
q_snk = reshape(Q_sink, 4, [])';
q_het = reshape(Q_het, 4, [])';

% Interpolation smoothing (increase number of interpolation points to handle high-frequency oscillations and make curves smoother)
t_fine = linspace(0, T_per, 200)';
q_src_fine = bary_interp_vector_4(q_src, t_orb, t_fine);
q_snk_fine = bary_interp_vector_4(q_snk, t_orb, t_fine);

% Increase heteroclinic orbit interpolation points to 1000 to ensure oscillation details are preserved
t_het_fine = linspace(0, T_total, 1000)'; 
q_het_fine = bary_interp_vector_4(q_het, t_het, t_het_fine);

% --- Fig 1: 3D Phase Space Topology ---
fig1 = figure('Position', [100, 100, 900, 700], 'Color', 'w');
ax1 = axes('Position', [0.1, 0.1, 0.85, 0.85]);
hold(ax1, 'on'); axis(ax1, 'equal'); grid(ax1, 'on'); view(3);

% 1. Plot Orbits (Source/Sink) 
% Source: Red solid line, bold
plot3(q_src_fine(:,2), q_src_fine(:,3), q_src_fine(:,4), ...
    'Color', colors.source, 'LineWidth', 3, 'LineStyle', '-');
% Sink: Blue solid line, bold
plot3(q_snk_fine(:,2), q_snk_fine(:,3), q_snk_fine(:,4), ...
    'Color', colors.sink, 'LineWidth', 3, 'LineStyle', '-');

% 2. Plot Heteroclinic Orbit - [Core Modification: Translucent thin solid line]
h_het = surface([q_het_fine(:,2), q_het_fine(:,2)], ...
        [q_het_fine(:,3), q_het_fine(:,3)], ...
        [q_het_fine(:,4), q_het_fine(:,4)], ...
        [q_het_fine(:,1), q_het_fine(:,1)], ...
        'FaceColor', 'no', ...
        'EdgeColor', 'interp', ...
        'LineWidth', 0.8, ...      
        'LineStyle', '-', ...      
        'EdgeAlpha', 0.5);          

% Colormap: Use jet or parula to reflect changes in scalar part q0
colormap(ax1, 'jet'); 
cb = colorbar(ax1); 
cb.Label.String = 'Scalar Part $q_0$'; 
cb.Label.Interpreter = 'latex';
cb.Label.FontSize = 12;

% 3. Mark Start and End Points 
start_pt = q_het_fine(1, 2:4);
end_pt = q_het_fine(end, 2:4);

% Start point
plot3(start_pt(1), start_pt(2), start_pt(3), 'o', ...
    'MarkerSize', 8, 'MarkerFaceColor', colors.source, 'MarkerEdgeColor', 'k', 'LineWidth', 1);
text(start_pt(1), start_pt(2), start_pt(3), '  Start', ...
    'Interpreter', 'latex', 'FontSize', 14, 'FontWeight', 'bold', 'Color', 'k', 'VerticalAlignment', 'bottom');

% End point
plot3(end_pt(1), end_pt(2), end_pt(3), 's', ...
    'MarkerSize', 8, 'MarkerFaceColor', colors.sink, 'MarkerEdgeColor', 'k', 'LineWidth', 1);
text(end_pt(1), end_pt(2), end_pt(3), '  End', ...
    'Interpreter', 'latex', 'FontSize', 14, 'FontWeight', 'bold', 'Color', 'k', 'VerticalAlignment', 'top');

% 4. Sparse Arrows 
idx_arrows = round(linspace(50, 950, 6)); 
for i = idx_arrows
    p = q_het_fine(i, 2:4);
    dp = q_het_fine(i+5, 2:4) - p; 
    len = norm(dp);
    if len > 0
        quiver3(p(1), p(2), p(3), dp(1), dp(2), dp(3), 0.5, ...
            'Color', [0.3 0.3 0.3], 'LineWidth', 1.5, 'MaxHeadSize', 1.5);
    end
end

xlabel('$q_1 (\mathbf{i})$', 'FontSize', 14); 
ylabel('$q_2 (\mathbf{j})$', 'FontSize', 14); 
zlabel('$q_3 (\mathbf{k})$', 'FontSize', 14);
title('\textbf{Fig 5.10. Heteroclinic Connection (Original System)}', 'Interpreter', 'latex', 'FontSize', 16);
grid on; box on;
view(135, 25);

% Update Legend
legend([ax1.Children(end-1), ax1.Children(end), h_het], ... 
    {'Source Orbit', 'Sink Orbit', 'Heteroclinic Path'}, ...
    'Location', 'best', 'Interpreter', 'latex', 'FontSize', 12);

% --- Fig 2: Norm Evolution ---
fig2 = figure('Position', [1050, 100, 600, 400], 'Color', 'w');
norm_het = sqrt(sum(q_het_fine.^2, 2));

plot(t_het_fine, norm_het, 'k-', 'LineWidth', 1.5); 
hold on;

yline(norm(Q_source(1:4)), 'r--', 'Source Norm', ...
    'LineWidth', 1.5, 'LabelHorizontalAlignment', 'left', 'LabelVerticalAlignment', 'bottom', 'FontSize', 12, 'Interpreter', 'latex');
yline(norm(Q_sink(1:4)), 'b--', 'Sink Norm', ...
    'LineWidth', 1.5, 'LabelHorizontalAlignment', 'right', 'LabelVerticalAlignment', 'top', 'FontSize', 12, 'Interpreter', 'latex');

xlabel('Time $t$', 'Interpreter', 'latex', 'FontSize', 14);
ylabel('Norm $\|q(t)\|$', 'Interpreter', 'latex', 'FontSize', 14);
title('\textbf{Fig 5.11. Transition Dynamics}', 'Interpreter', 'latex', 'FontSize', 16);
grid on;
ylim([min(norm_het)*0.9, max(norm_het)*1.1]);
%% --- 5. Generate Animation ---
fprintf('Step 4: Generating Animation (Slow Motion)...\n');

% Create new figure window for animation
fig_anim = figure('Position', [150, 150, 900, 700], 'Color', 'w');
ax_anim = axes('Position', [0.1, 0.1, 0.85, 0.85]);
hold(ax_anim, 'on'); axis(ax_anim, 'equal'); grid(ax_anim, 'on'); view(3);
xlabel('$q_1 (\mathbf{i})$', 'FontSize', 14); 
ylabel('$q_2 (\mathbf{j})$', 'FontSize', 14); 
zlabel('$q_3 (\mathbf{k})$', 'FontSize', 14);
title('\textbf{Heteroclinic Trajectory Evolution}', 'Interpreter', 'latex', 'FontSize', 16);
view(135, 25); % Maintain same viewpoint as static plot

% 1. Source and Sink Orbits (Static Background)
plot3(q_src_fine(:,2), q_src_fine(:,3), q_src_fine(:,4), ...
    'Color', colors.source, 'LineWidth', 2, 'LineStyle', '--');
plot3(q_snk_fine(:,2), q_snk_fine(:,3), q_snk_fine(:,4), ...
    'Color', colors.sink, 'LineWidth', 2, 'LineStyle', '--');

% Mark start and end points
plot3(start_pt(1), start_pt(2), start_pt(3), 'o', 'MarkerSize', 8, 'MarkerFaceColor', colors.source, 'MarkerEdgeColor', 'k');
plot3(end_pt(1), end_pt(2), end_pt(3), 's', 'MarkerSize', 8, 'MarkerFaceColor', colors.sink, 'MarkerEdgeColor', 'k');

% 2. Initialize Animation Objects
% Moving point (Head) 
h_head = plot3(q_het_fine(1,2), q_het_fine(1,3), q_het_fine(1,4), 'o', ...
    'MarkerSize', 10, 'MarkerFaceColor', 'k', 'MarkerEdgeColor', 'w');

% Trajectory line (Tail) - Initially empty
h_tail = animatedline('Color', [0.2 0.2 0.2], 'LineWidth', 1.5);

% 3. Animation Loop Settings
n_points = length(t_het_fine); % Total points (Assuming 1000)
step_size = 1;                 % Step size (Smaller is smoother but computationally heavier)
frames_to_draw = floor(n_points / step_size);

% --- Time Control Core ---
target_duration = 20;          
delay_per_frame = target_duration / frames_to_draw; % Pause time per frame

% If GIF saving is needed
save_gif = true; 
gif_filename = 'heteroclinic_slow.gif';

fprintf('  > Animation started. Target duration: %.1fs\n', target_duration);

for i = 1:step_size:n_points
    % Current position
    curr_pos = q_het_fine(i, 2:4);
    
    % Update moving point position
    set(h_head, 'XData', curr_pos(1), 'YData', curr_pos(2), 'ZData', curr_pos(3));
    
    % Update trajectory line (Add new points)
    if i > 1
        prev_idx = max(1, i-step_size);
        % Add all points in this segment to ensure line continuity
        addpoints(h_tail, q_het_fine(prev_idx:i, 2), q_het_fine(prev_idx:i, 3), q_het_fine(prev_idx:i, 4));
    end
    
    % Update title display time
    title(sprintf('\\textbf{Time} $t = %.2f$ / %.2f', t_het_fine(i), T_total), 'Interpreter', 'latex');
    
    drawnow; 
    pause(delay_per_frame); 
    
    % Save GIF frame
    if save_gif
        frame = getframe(fig_anim);
        im = frame2im(frame);
        [imind, cm] = rgb2ind(im, 256);
        if i == 1
            imwrite(imind, cm, gif_filename, 'gif', 'Loopcount', inf, 'DelayTime', delay_per_frame);
        else
            imwrite(imind, cm, gif_filename, 'gif', 'WriteMode', 'append', 'DelayTime', delay_per_frame);
        end
    end
end

fprintf('Animation finished.\n');