function [Q, flag] = solve_bvp_fsolve_4(Q_guess, D, A, C, q_start, q_end)
    fun = @(x) residual_bvp_4(x, D, A, C, q_start, q_end);
    
    options = optimoptions('fsolve', 'Display', 'iter', ...
        'Algorithm', 'trust-region-dogleg', ...
        'FunctionTolerance', 1e-6, 'StepTolerance', 1e-6);
    
    [Q, ~, flag] = fsolve(fun, Q_guess, options);
end