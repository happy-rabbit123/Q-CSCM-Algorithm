function q_out = qmult_vec_4(q1, q2)
    n1 = size(q1,1); n2 = size(q2,1);
    if n1~=n2, if n1==1, q1=repmat(q1,n2,1); else, q2=repmat(q2,n1,1); end; end
    s1 = q1(:,1); v1 = q1(:,2:4);
    s2 = q2(:,1); v2 = q2(:,2:4);
    s = s1.*s2 - dot(v1, v2, 2);
    v = s1.*v2 + s2.*v1 + cross(v1, v2, 2);
    q_out = [s, v];
end