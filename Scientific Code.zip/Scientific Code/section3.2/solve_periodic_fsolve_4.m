function [Q, flag] = solve_periodic_fsolve_4(Q_guess, D, A, C)
    % Objective function: Residual = 0
    fun = @(x) residual_periodic_4(x, D, A, C);
    
    % Set fsolve options (Trust-region algorithm, robust)
    options = optimoptions('fsolve', 'Display', 'off', ...
        'Algorithm', 'trust-region-dogleg', ...
        'FunctionTolerance', 1e-8, 'StepTolerance', 1e-8);
    
    [Q, ~, flag] = fsolve(fun, Q_guess, options);
end
