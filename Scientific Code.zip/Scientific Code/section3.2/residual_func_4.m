function F = residual_func_4(Q, D, t, a_fun, c_fun, q_start, q_end)
    N = length(t)-1;
    Q_mat = reshape(Q, 4, [])';
    dQ = reshape(D*Q, 4, [])';
    
    A = a_fun(t); C = c_fun(t);
    qa = qmult_vec(Q_mat, A);
    qaq = qmult_vec(qa, Q_mat);
    Res_mat = dQ - (qaq + C);
    F = reshape(Res_mat', [], 1);
    
    % BC
    row1 = 1:4; F(row1) = Q(1:4) - q_start';
    row2 = 4*N+1:4*(N+1); F(row2) = Q(end-3:end) - q_end';
end