function dq = riccati_rhs_val_4(t, q, a_fun, c_fun)
    if size(q,1)==4, q=q'; end
    A = a_fun(t); C = c_fun(t);
    % q_dot = q * A * q + C
    qa = qmult_vec_4(q, A);
    qaq = qmult_vec_4(qa, q);
    dq = (qaq + C)';
end