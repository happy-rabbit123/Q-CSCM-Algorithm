function [Q, conv] = newton_solver_periodic_4(Q_guess, D, t, a_fun, c_fun)
    Q = Q_guess; conv = false;
    N = length(t)-1;
    for iter = 1:20
        Q_mat = reshape(Q, 4, [])';
        dQ = reshape(D*Q, 4, [])';
        
        A = a_fun(t); C = c_fun(t);
        qa = qmult_vec_4(Q_mat, A);
        qaq = qmult_vec_4(qa, Q_mat);
        Res_mat = dQ - (qaq + C);
        F = reshape(Res_mat', [], 1);
        
        if norm(F, inf) < 1e-10, conv = true; return; end
        
        % Jacobian: d(qAq) = dq A q + q A dq
        L_coeff = qa;
        R_coeff = qmult_vec_4(A, Q_mat);
        
        Blk_L = cell(N+1,1); Blk_R = cell(N+1,1);
        for k=1:N+1
            Blk_L{k} = qmatL_4(L_coeff(k,:));
            Blk_R{k} = qmatR_4(R_coeff(k,:));
        end
        J_alg = blkdiag(Blk_L{:}) + blkdiag(Blk_R{:});
        Jac = D - J_alg;
        
        % Periodic BC
        row = 4*N+1:4*(N+1);
        Jac(row,:) = 0; Jac(row, 1:4) = eye(4); Jac(row, end-3:end) = -eye(4);
        F(row) = Q(1:4) - Q(end-3:end);
        
        Q = Q - Jac \ F;
    end
end