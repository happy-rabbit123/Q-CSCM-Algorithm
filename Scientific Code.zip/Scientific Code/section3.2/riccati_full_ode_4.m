function dq = riccati_full_ode_4(t, q, xi, eta, u, f)
    % Ensure q is a row vector
    if size(q,1)==4, q=q'; end
    
    % Get coefficients at current time
    Xi = xi(t); 
    Eta = eta(t); 
    U = u(t); 
    F = f(t);
    
    % Compute equation: (q-xi) * u * (q-eta) + f
    term1 = q - Xi;
    term2 = q - Eta;
    
    % Perform quaternion multiplication step-by-step
    % temp = (q-xi) * u
    temp = qmult_vec_4(term1, U);
    % res = temp * (q-eta) + f
    res = qmult_vec_4(temp, term2) + F;
    
    dq = res'; % Return column vector to ode45
end