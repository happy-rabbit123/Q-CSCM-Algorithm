function h = plot_tube_4(x, y, z, r, col)
    [X,Y,Z] = tube_mesh(x, y, z, r, 10);
    h = surf(X, Y, Z, 'FaceColor', col, 'EdgeColor', 'none', 'FaceAlpha', 0.6);
end
