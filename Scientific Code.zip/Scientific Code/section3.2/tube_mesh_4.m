function [X,Y,Z] = tube_mesh_4(x,y,z,r,n)
    N = length(x);
    theta = linspace(0, 2*pi, n+1);
    X = zeros(n+1, N); Y = X; Z = X;
    for i=1:N
        if i<N, v = [x(i+1)-x(i), y(i+1)-y(i), z(i+1)-z(i)];
        else, v = [x(i)-x(i-1), y(i)-y(i-1), z(i)-z(i-1)]; end
        v = v/norm(v);
        if abs(v(1)) < 0.9, n_vec = cross(v, [1,0,0]); else, n_vec = cross(v, [0,1,0]); end
        n_vec = n_vec/norm(n_vec);
        b_vec = cross(v, n_vec);
        for j=1:n+1
            p = r * (cos(theta(j))*n_vec + sin(theta(j))*b_vec);
            X(j,i) = x(i) + p(1);
            Y(j,i) = y(i) + p(2);
            Z(j,i) = z(i) + p(3);
        end
    end
end