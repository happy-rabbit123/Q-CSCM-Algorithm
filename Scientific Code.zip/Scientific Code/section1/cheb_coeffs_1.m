function c = cheb_coeffs_1(v)
    % Compute Chebyshev coefficients using FFT
    N = length(v) - 1;
    v_ext = [v; flipud(v(2:N))]; % Even extension
    f = fft(v_ext);
    c = real(f(1:N+1));
    c = c / N;
    c(1) = c(1) / 2;
    c(end) = c(end) / 2;
end