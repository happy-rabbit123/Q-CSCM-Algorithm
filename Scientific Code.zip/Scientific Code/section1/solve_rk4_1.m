function q_out = solve_rk4_1(t_vec, h, A_fun, B_fun, f_fun, q0)
    M = length(t_vec) - 1;
    q_out = zeros(M+1, 4);
    q_out(1, :) = q0;
    y = q0(:);
    for k = 1:M
        tk = t_vec(k);
        k1 = rhs_sys_1(tk,       y,          A_fun, B_fun, f_fun);
        k2 = rhs_sys_1(tk + h/2, y + h/2*k1, A_fun, B_fun, f_fun);
        k3 = rhs_sys_1(tk + h/2, y + h/2*k2, A_fun, B_fun, f_fun);
        k4 = rhs_sys_1(tk + h,   y + h*k3,   A_fun, B_fun, f_fun);
        y = y + (h/6) * (k1 + 2*k2 + 2*k3 + k4);
        q_out(k+1, :) = y';
    end
end