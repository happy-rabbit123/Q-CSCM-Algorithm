function BR = get_BR_1(q)
    % Right-multiplication real representation matrix Chi_R (standard definition)
    % q = q0 + q1*i + q2*j + q3*k
    % Variable mapping: q(1)->q0, q(2)->q1, q(3)->q2, q(4)->q3
    
    q0=q(1); q1=q(2); q2=q(3); q3=q(4);
    
    BR = [q0, -q1, -q2, -q3;
          q1,  q0,  q3, -q2;
          q2, -q3,  q0,  q1;
          q3,  q2, -q1,  q0];
end