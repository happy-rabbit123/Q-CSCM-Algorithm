function [q_out, t] = solve_qcscm_1(N, t_start, t_end, A_fun, B_fun, f_fun, q0)
    [D, x] = cheb_1(N); 
    scale = (t_end - t_start) / 2;
    t = (x + 1) * scale + t_start;
    D = D / scale; 
    
    dim = 4 * (N+1);
    D_global = kron(D, eye(4));
    
    M_cell = cell(1, N+1);
    F_vec = zeros(dim, 1);
    
    for i = 1:N+1
        ti = t(i);
        AL = get_AL_1(A_fun(ti));
        BR = get_BR_1(B_fun(ti));
        Mi = AL + BR; 
        M_cell{i} = Mi;
        fi = f_fun(ti);
        F_vec((i-1)*4 + (1:4)) = fi(:);
    end
    M_global = blkdiag(M_cell{:});
    K = D_global - M_global;
    
    idx_start = N*4 + 1; 
    idx_range = idx_start : idx_start+3;
    K(idx_range, :) = 0;
    K(idx_range, idx_range) = eye(4);
    F_vec(idx_range) = q0(:);
    
    Q_sol = K \ F_vec;
    q_out = reshape(Q_sol, 4, N+1)';
end