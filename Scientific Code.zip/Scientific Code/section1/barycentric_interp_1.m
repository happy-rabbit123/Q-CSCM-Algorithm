function y_interp = barycentric_interp_1(x_nodes, y_nodes, x_query)
    % Barycentric interpolation formula (Chebyshev points of the second kind)
    N = length(x_nodes) - 1;
    w = [0.5; ones(N-1,1); 0.5] .* (-1).^(0:N)'; % Weights
    
    num = zeros(length(x_query), 4);
    den = zeros(length(x_query), 1);
    
    for j = 1:N+1
        diff = x_query - x_nodes(j);
        mask_zero = abs(diff) < 1e-14; % Handle coincident points
        diff(mask_zero) = 1e-14;       % Avoid division by zero
        
        weight = w(j) ./ diff;
        % For coincident points, set weights to be extremely large to naturally approximate the node values
        weight(mask_zero) = 1e100; 
        
        num = num + weight .* y_nodes(j, :);
        den = den + weight;
    end
    y_interp = num ./ den;
end