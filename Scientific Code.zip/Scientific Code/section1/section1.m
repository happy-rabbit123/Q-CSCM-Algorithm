%% Experiment 5.1: Benchmark of Spectral Accuracy (Final Polish)
clear; clc; close all;

%% 1. Problem Setup
T_start = -1;
T_end   = 1;

% Exact solution (Analytical function, corresponding to s -> inf)
q_fun = @(t) [sin(t), exp(sin(pi*t)), cos(5*t), 1./(1 + t.^2)];

% Derivative of the exact solution
dq_fun = @(t) [cos(t), ...
               pi*cos(pi*t).*exp(sin(pi*t)), ...
               -5*sin(5*t), ...
               -2*t./((1 + t.^2).^2)];

% Coefficient matrices
A_fun = @(t) [ -0.5,  cos(t),  sin(t),  0 ]; 
B_fun = @(t) [ -0.2,  0,       cos(2*t), sin(2*t) ]; 

% Source term
f_fun = @(t) calc_source_term_1(t, q_fun, dq_fun, A_fun, B_fun);

% Initial value
q0 = q_fun(T_start); 

%% 2. Algorithm Execution
N_list = [4, 8, 12, 16, 20, 24, 28, 32]; 
M_list = [10, 50, 100, 500, 1000, 5000]; 

% --- Q-CSCM ---
err_qcscm = [];
time_qcscm = [];
for N = N_list
    tic;
    [q_num, t_nodes] = solve_qcscm_1(N, T_start, T_end, A_fun, B_fun, f_fun, q0);
    t_cost = toc;
    
    % Compute maximum error ||E||_inf
    err_val = 0;
    for i = 1:length(t_nodes)
        err_val = max(err_val, norm(q_num(i,:) - q_fun(t_nodes(i))));
    end
    err_qcscm = [err_qcscm; err_val];
    time_qcscm = [time_qcscm; t_cost];
end

% --- RK4 ---
err_rk4 = [];
time_rk4 = [];
for M = M_list
    h = (T_end - T_start)/M;
    t_rk = linspace(T_start, T_end, M+1)';
    tic;
    q_rk = solve_rk4_1(t_rk, h, A_fun, B_fun, f_fun, q0);
    t_cost = toc;
    err_val = 0;
    for i = 1:length(t_rk)
        err_val = max(err_val, norm(q_rk(i,:) - q_fun(t_rk(i))));
    end
    err_rk4 = [err_rk4; err_val];
    time_rk4 = [time_rk4; t_cost];
end
%% 3. Additional Analysis: Generate Comparison Data

% --- A. Generate Time-History Error Data ---
% Select a medium-accuracy RK4 (M=1000) and a medium-accuracy Q-CSCM (N=24) for comparison
M_compare = 1000;
N_compare = 40;

% 1. RK4 error trajectory
h_cmp = (T_end - T_start)/M_compare;
t_rk_dense = linspace(T_start, T_end, M_compare+1)';
q_rk_sol = solve_rk4_1(t_rk_dense, h_cmp, A_fun, B_fun, f_fun, q0);
% Compute RK4 exact solution
q_true_rk = zeros(length(t_rk_dense), 4);
for i=1:length(t_rk_dense), q_true_rk(i,:) = q_fun(t_rk_dense(i)); end
err_time_rk4 = vecnorm(q_rk_sol - q_true_rk, 2, 2);

% 2. Q-CSCM error trajectory (Interpolate to the same dense grid for fair comparison)
[q_spec_sol, t_spec_nodes] = solve_qcscm_1(N_compare, T_start, T_end, A_fun, B_fun, f_fun, q0);
% Map spectral solution to RK4 time points using barycentric interpolation
q_spec_interp = barycentric_interp_1(t_spec_nodes, q_spec_sol, t_rk_dense);
err_time_qcscm = vecnorm(q_spec_interp - q_true_rk, 2, 2);

% --- B. Generate Quantitative Table Data ---
% Calculate Convergence Rate (EOC) for RK4
fprintf('\n=== Table 1: Numerical Errors and Convergence Rates (RK4) ===\n');
fprintf('%6s | %12s | %12s | %8s | %6s\n', 'Steps', 'L2 Error', 'Linf Error', 'Time(s)', 'EOC');
fprintf('-------------------------------------------------------------\n');
last_err = 0;
for k = 1:length(M_list)
    M = M_list(k);
    curr_err = err_rk4(k); 
    time_val = time_rk4(k);
    
    if k > 1
        % EOC = log(E1/E2) / log(N2/N1)
        rate = log(last_err / curr_err) / log(M / M_list(k-1));
        fprintf('%6d | %12.4e | %12.4e | %8.4f | %6.2f\n', M, curr_err, curr_err, time_val, rate);
    else
        fprintf('%6d | %12.4e | %12.4e | %8.4f | %6s\n', M, curr_err, curr_err, time_val, '-');
    end
    last_err = curr_err;
end

fprintf('\n=== Table 2: Spectral Accuracy (Q-CSCM) ===\n');
fprintf('%6s | %12s | %12s | %8s\n', 'N', 'L2 Error', 'Linf Error', 'Time(s)');
fprintf('--------------------------------------------------\n');
for k = 1:length(N_list)
    fprintf('%6d | %12.4e | %12.4e | %8.4f\n', N_list(k), err_qcscm(k), err_qcscm(k), time_qcscm(k));
end


%% 4. Advanced Plotting (Paper Quality - Updated)
% Set default font size and line width
set(0, 'DefaultAxesFontSize', 12, 'DefaultAxesFontName', 'Times New Roman');
set(0, 'DefaultLineLineWidth', 1.5);

figure('Position', [50, 50, 1400, 900]); 

% --- (a) Convergence Rate ---
subplot(2, 3, 1);
loglog(M_list, err_rk4, 'b--o', 'MarkerSize', 6); hold on;
loglog(N_list, err_qcscm, 'r-s', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
yline(eps, 'k:', 'Label', 'Machine \epsilon', 'LabelVerticalAlignment', 'bottom'); 
grid on;
xlabel('Degrees of Freedom ($N$ or Steps)', 'Interpreter', 'latex');
ylabel('Error $\|\mathbf{E}\|_\infty$', 'Interpreter', 'latex'); 
title('(a) Convergence Comparison');
legend({'RK4 (Algebraic $O(N^{-4})$)', 'Q-CSCM (Exponential)'}, ...
       'Location', 'SouthWest', 'Interpreter', 'latex');
axis tight;

% --- (b) Efficiency ---
subplot(2, 3, 2);
loglog(time_rk4, err_rk4, 'b--o'); hold on;
loglog(time_qcscm, err_qcscm, 'r-s', 'MarkerFaceColor', 'r');
grid on;
xlabel('CPU Time (seconds)', 'Interpreter', 'latex');
ylabel('Error $\|\mathbf{E}\|_\infty$', 'Interpreter', 'latex');
title('(b) Computational Efficiency');
legend({'RK4', 'Q-CSCM'}, 'Location', 'NorthEast', 'Interpreter', 'latex');

% --- (c) Time-History Error Comparison ---
subplot(2, 3, 3);
semilogy(t_rk_dense, err_time_rk4, 'b--', 'LineWidth', 1); hold on;
semilogy(t_rk_dense, err_time_qcscm + eps, 'r-', 'LineWidth', 1.5); % +eps to avoid log(0)
grid on;
xlabel('Time $t$', 'Interpreter', 'latex');
ylabel('Pointwise Error $\|\mathbf{e}(t)\|$', 'Interpreter', 'latex');
title({'(c) Error Evolution over Time', ['(RK4 $M=',num2str(M_compare),'$ vs Q-CSCM $N=',num2str(N_compare),'$)']}, 'Interpreter', 'latex');
legend({'RK4 Error', 'Q-CSCM Error'}, 'Location', 'Best', 'Interpreter', 'latex');
ylim([1e-16, 1e-2]); % Lock y-axis range for comparison

% --- (d) Spectral Coefficients (Spectral Decay) ---
% Compute Chebyshev coefficients of the numerical solution (using N=32)
N_demo = 32;
[q_sol_demo, ~] = solve_qcscm_1(N_demo, T_start, T_end, A_fun, B_fun, f_fun, q0);
coeffs = zeros(N_demo+1, 4);
for dim = 1:4
    coeffs(:, dim) = cheb_coeffs_1(q_sol_demo(:, dim));
end
coeff_mag = vecnorm(coeffs, 2, 2);

subplot(2, 3, 4);
semilogy(0:N_demo, coeff_mag, 'b-o', 'MarkerFaceColor', 'b', 'MarkerSize', 4);
grid on;
xlabel('Mode Number $k$', 'Interpreter', 'latex');
ylabel('Coefficient Magnitude $|\hat{c}_k|$', 'Interpreter', 'latex'); 
title('(d) Spectral Coefficients Decay');
text(10, 1e-5, 'Exponential Decay', 'FontSize', 10, 'Interpreter', 'latex');

% --- (e) Solution Trajectory (New: Display solution trajectory) ---
% Demonstrate solution complexity to prove it's not solving a constant equation
subplot(2, 3, [5, 6]); % Occupy the last two positions
plot(t_rk_dense, q_true_rk(:,1), 'k-', 'LineWidth', 1); hold on;
plot(t_rk_dense, q_true_rk(:,2), 'r-.', 'LineWidth', 1);
plot(t_rk_dense, q_true_rk(:,3), 'g--', 'LineWidth', 1);
plot(t_rk_dense, q_true_rk(:,4), 'b:', 'LineWidth', 1);
grid on;
xlabel('Time $t$', 'Interpreter', 'latex');
ylabel('Component Value', 'Interpreter', 'latex');
title('(e) Dynamics of Quaternion Components (Exact Solution)');
legend({'$q_0$ (Scalar)', '$q_1$ (i)', '$q_2$ (j)', '$q_3$ (k)'}, 'Interpreter', 'latex', 'NumColumns', 4);