function f = calc_source_term_1(t, q_fun, dq_fun, A_fun, B_fun)
    q = q_fun(t); dq = dq_fun(t); A = A_fun(t); B = B_fun(t);
    f = dq - (qmult_1(A, q) + qmult_1(q, B));
end
