function dydt = rhs_sys_1(t, y, A_fun, B_fun, f_fun)
    A = A_fun(t); B = B_fun(t); f = f_fun(t);
    AL = get_AL_1(A); BR = get_BR_1(B);
    dydt = (AL + BR) * y + f(:);
end
