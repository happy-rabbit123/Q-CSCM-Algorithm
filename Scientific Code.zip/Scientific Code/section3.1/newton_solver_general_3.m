function [Q, converged] = newton_solver_general_3(Q_guess, D_global, A_val, B_val, C_val, D_val)
    Q = Q_guess;
    max_iter = 20;
    tol = 1e-10;
    converged = false;
    N = size(A_val, 1) - 1;
    
    for iter = 1:max_iter
        Q_mat = reshape(Q, 4, [])'; 
        dQ = reshape(D_global * Q, 4, [])';
        
        qa = qmult_vec(Q_mat, A_val);
        qaq = qmult_vec(qa, Q_mat);
        bq = qmult_vec(B_val, Q_mat);
        qd = qmult_vec(Q_mat, D_val);
        
        Res_mat = dQ - (qaq + bq + qd + C_val);
        F = reshape(Res_mat', [], 1);
        
        if norm(F, inf) < tol
            converged = true;
            return;
        end
        
        L_coeff = qa + B_val; 
        R_coeff = qmult_vec(A_val, Q_mat) + D_val; 
        
        Blk_L = cell(N+1, 1);
        Blk_R = cell(N+1, 1);
        
        for k = 1:N+1
            Blk_L{k} = qmatL(L_coeff(k,:));
            % Correction: Right-multiplication matrix must be transposed!
            Blk_R{k} = qmatR(R_coeff(k,:))'; 
        end
        
        J_alg = blkdiag(Blk_L{:}) + blkdiag(Blk_R{:});
        Jac = D_global - J_alg;
        
        row_idx = 4*N+1 : 4*(N+1);
        col_idx_start = 1:4;
        col_idx_end = 4*N+1 : 4*(N+1);
        Jac(row_idx, :) = 0;
        Jac(row_idx, col_idx_start) = eye(4);
        Jac(row_idx, col_idx_end) = -eye(4);
        F(row_idx) = Q(col_idx_start) - Q(col_idx_end);
        
        delta = Jac \ (-F);
        Q = Q + delta;
    end
end