function [Q, converged] = newton_solver_robust_3(Q, D_global, t_nodes, a_fun, c_fun)
    N = length(t_nodes)-1;
    idx_T = 1:4; idx_0 = 4*N + (1:4);
    
    last_res = inf;
    lambda = 1.0; % Damping factor
    
    for iter = 1:30
        % 1. Assemble residual and Jacobian
        F = zeros(4*(N+1), 1);
        J_diag = cell(N+1, 1);
        
        for i = 1:N+1
            ti = t_nodes(i);
            qi = Q((i-1)*4+1 : i*4);
            ai = a_fun(ti)'; ci = c_fun(ti)';
            
            qa = qmult_3(qi, ai);
            qaq = qmult_3(qa, qi);
            F((i-1)*4+1 : i*4) = - (qaq + ci); 
            
            aq = qmult_3(ai, qi);
            J_diag{i} = -(get_chi_3(qa, 'L') + get_chi_3(aq, 'R'));
        end
        
        Residual = D_global * Q + F;
        Jacobian = D_global + blkdiag(J_diag{:});
        
        % 2. Periodic boundary conditions
        Jacobian(idx_0, :) = 0;
        Jacobian(idx_0, idx_0) = eye(4);
        Jacobian(idx_0, idx_T) = -eye(4);
        Residual(idx_0) = Q(idx_0) - Q(idx_T);
        
        curr_res = norm(Residual);
        fprintf('  Iter %d: Residual = %.4e (lambda=%.2f)\n', iter, curr_res, lambda);
        
        if curr_res < 1e-10, converged = true; return; end
        
        % 3. Damping update strategy
        if curr_res > last_res
            lambda = lambda * 0.5; % Residual increased, decrease step size
        else
            lambda = min(1.0, lambda * 1.2); % Residual decreased, try increasing step size
        end
        
        delta = -Jacobian \ Residual;
        Q = Q + lambda * delta;
        last_res = curr_res;
    end
    converged = false;
end