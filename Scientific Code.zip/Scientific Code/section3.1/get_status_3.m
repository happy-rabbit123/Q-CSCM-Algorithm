function status = get_status_3(rho)
    if rho < 1 - 1e-4
        status = 'STABLE';
    elseif rho > 1 + 1e-4
        status = 'UNSTABLE';
    else
        status = 'NEUTRAL/CRITICAL';
    end
end