function q_interp = bary_interp_vector_3(q_nodes, t_nodes, t_query)
    N = size(q_nodes, 1) - 1;
    w = [0.5; ones(N-1,1); 0.5] .* (-1).^(0:N)';
    num = zeros(length(t_query), 4);
    den = zeros(length(t_query), 1);
    for j = 1:N+1
        diff = t_query(:) - t_nodes(j);
        diff(abs(diff)<1e-14) = 1e-14;
        weight = w(j) ./ diff;
        num = num + weight .* q_nodes(j,:);
        den = den + weight;
    end
    q_interp = num ./ den;
end
