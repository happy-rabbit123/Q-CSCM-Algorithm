function add_flow_arrows_fixed_3(ax, q, idxs, col, arrow_len)
    % q: Nx4 matrix
    % idxs: indices
    % arrow_len: Absolute length of the arrow
    
    for k = idxs
        % Start point
        pos = q(k, 2:4);
        
        % Compute tangent direction (normalized)
        tangent = q(k+5, 2:4) - q(k, 2:4); 
        tangent = tangent / norm(tangent);
        
        % Enforce vector length
        u = tangent(1) * arrow_len;
        v = tangent(2) * arrow_len;
        w = tangent(3) * arrow_len;
        
        % Key parameter: 'AutoScale', 'off' 
        quiver3(ax, pos(1), pos(2), pos(3), u, v, w, ...
            0, ... % Scale = 0 means disable auto-scaling
            'Color', col, 'LineWidth', 2.5, 'MaxHeadSize', 0.8, 'HandleVisibility', 'off');
    end
end