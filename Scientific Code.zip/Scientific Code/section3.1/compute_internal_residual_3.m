function res = compute_internal_residual_3(Q, D_global, t_nodes, a_fun, c_fun)
    % Compute global derivative
    Q_dot_num = D_global * Q;
    
    % Compute right-hand side of the physical equation
    N = length(t_nodes) - 1;
    rhs_val = zeros(4*(N+1), 1);
    for i = 1:N+1
        idx = (i-1)*4 + (1:4);
        qi = Q(idx);
        ti = t_nodes(i);
        % f(q,t) = q * a(t) * q + c(t)
        rhs_val(idx) = qmult_3(qmult_3(qi, a_fun(ti)'), qi) + c_fun(ti)';
    end
    
    % Key: Only take the first N points (exclude the last boundary point, as it was replaced by BC)
    % Actually, Chebyshev points are usually defined as 0..N, totaling N+1 points.
    % Our solver enforces Q(0)=Q(T) at the (N+1)-th point (t_nodes(end)).
    % Therefore, we check the equation residual for the first N points.
    valid_indices = 1 : 4*N; 
    
    diff = Q_dot_num - rhs_val;
    res = norm(diff(valid_indices), inf);
end