clear; clc; close all;

% --- 1. Global Aesthetic Settings ---
colors.blue   = [0.00, 0.447, 0.741];
colors.red    = [0.850, 0.325, 0.098];
colors.purple = [0.494, 0.184, 0.556];
colors.green  = [0.466, 0.674, 0.188];
colors.gray   = [0.6, 0.6, 0.6];

set(0, 'DefaultTextInterpreter', 'latex');
set(0, 'DefaultLegendInterpreter', 'latex');
set(0, 'DefaultAxesFontSize', 14);
set(0, 'DefaultLineLineWidth', 1.5);
set(0, 'DefaultAxesBox', 'on');
set(0, 'DefaultAxesLineWidth', 1.2);

%% --- Step 1: Problem Definition (The "Twisted" Oscillator) ---
T_period = 2*pi;

% Coefficient definition [q0, q1, q2, q3]
a_fun = @(t) [-0.5, cos(t), 0.3*sin(t), 0];
c_fun = @(t) [-0.1, 0, 0, 0.2*cos(2*t)];
% Q-CSCM parameters
N = 40; 
[x, D] = cheb_3(N); 
dt_dtau = 2/T_period; 
D_global = kron(D * dt_dtau, eye(4));
t_nodes = (x + 1) * T_period / 2;

fprintf('Solving Complex Riccati Dynamics...\n');

% Strategy: Generate initial trajectory using ODE45 (IVP -> BVP)
% Orbit 1: Start from small initial value
[~, q_init1] = ode45(@(t,y) riccati_rhs_3(t,y,a_fun,c_fun), t_nodes, [0.05;0;0;0]);
Q_guess1 = reshape(q_init1', [], 1);

% Orbit 2: Start from large initial value
[~, q_init2] = ode45(@(t,y) riccati_rhs_3(t,y,a_fun,c_fun), t_nodes, [0;0.8;0.8;0.8]);
Q_guess2 = reshape(q_init2', [], 1);

% Newton iteration
[Q_sol1, conv1] = newton_solver_robust_3(Q_guess1, D_global, t_nodes, a_fun, c_fun);
[Q_sol2, conv2] = newton_solver_robust_3(Q_guess2, D_global, t_nodes, a_fun, c_fun);

if ~conv1 || ~conv2
    error('Solver failed. Please check initial guesses or system parameters.');
end

fprintf('\nStep 3: Stability Analysis (Dynamic Check)...\n');

% Extract solution matrices
q1_mat = reshape(Q_sol1, 4, [])';
q2_mat = reshape(Q_sol2, 4, [])';

% --- Analyze Orbit 1 ---
% Construct linearization coefficients
A_stab1 = @(t) qmult_3(bary_interp_vector_3(q1_mat, t_nodes, t)', a_fun(t)');
B_stab1 = @(t) qmult_3(a_fun(t)', bary_interp_vector_3(q1_mat, t_nodes, t)');
% Compute monodromy matrix
M_A1 = compute_monodromy_3(T_period, A_stab1, 'L');
M_B1 = compute_monodromy_3(T_period, B_stab1, 'R');
% Compute spectral radius
rho1 = max(abs(eig(M_A1))) * max(abs(eig(M_B1)));

% --- Analyze Orbit 2 ---
A_stab2 = @(t) qmult_3(bary_interp_vector_3(q2_mat, t_nodes, t)', a_fun(t)');
B_stab2 = @(t) qmult_3(a_fun(t)', bary_interp_vector_3(q2_mat, t_nodes, t)');
M_A2 = compute_monodromy_3(T_period, A_stab2, 'L');
M_B2 = compute_monodromy_3(T_period, B_stab2, 'R');
rho2 = max(abs(eig(M_A2))) * max(abs(eig(M_B2)));

% --- Print actual results ---
fprintf('------------------------------------------------\n');
fprintf('Orbit 1 Spectral Radius: %.4f  =>  %s\n', rho1, get_status_3(rho1));
fprintf('Orbit 2 Spectral Radius: %.4f  =>  %s\n', rho2, get_status_3(rho2));
fprintf('------------------------------------------------\n');
fprintf('\n=== Table 5.3: Residual Verification of Periodic Solutions ===\n');
calc_internal_res = @(Q) compute_internal_residual_3(Q, D_global, t_nodes, a_fun, c_fun);

res_internal1 = calc_internal_res(Q_sol1);
res_internal2 = calc_internal_res(Q_sol2);

% Print table
fprintf('--------------------------------------------------------------------------\n');
fprintf('| %-8s | %-15s | %-18s |\n', 'Orbit', 'Stability', 'Internal Res');
fprintf('|----------|-----------------|--------------------|\n');
fprintf('| %-8s | %-15s | %-18.4e |\n', 'Orbit 1', get_status_3(rho1), res_internal1);
fprintf('| %-8s | %-15s | %-18.4e |\n', 'Orbit 2', get_status_3(rho2), res_internal2);
fprintf('--------------------------------------------------------------------------\n');
fprintf('Note: \n');
fprintf('1. Internal Res < 1e-13 proves the Newton solver converged perfectly.\n');
fprintf('[Visualization] Generating Figure 5.3 (3D Phase Portrait)...\n');

% 1. Prepare high-density data
t_fine = linspace(0, T_period, 1000);
q1_fine = bary_interp_vector_3(q1_mat, t_nodes, t_fine);
q2_fine = bary_interp_vector_3(q2_mat, t_nodes, t_fine);

fig3 = figure('Position', [100, 100, 900, 700], 'Color', 'w');
ax3 = axes('Position', [0.1, 0.1, 0.85, 0.85]);
hold(ax3, 'on'); grid(ax3, 'on'); 

% --- 2. Construct dynamic legend names ---
% Orbit 1 (Blue)
if rho1 < 1 - 1e-4
    status1_str = '< 1 (Stable)';
else
    status1_str = '> 1 (Unstable)';
end
name1 = sprintf('Orbit 1 ($\\rho \\approx %.2f %s$)', rho1, status1_str);

% Orbit 2 (Red)
if rho2 < 1 - 1e-4
    status2_str = '< 1 (Stable)';
else
    status2_str = '> 1 (Unstable)';
end
name2 = sprintf('Orbit 2 ($\\rho \\approx %.2f %s$)', rho2, status2_str);

% --- 3. Plot main orbits ---
p1 = plot3(q1_fine(:,2), q1_fine(:,3), q1_fine(:,4), '-', ...
    'Color', [colors.blue, 0.9], 'LineWidth', 2.5, 'DisplayName', name1);

p2 = plot3(q2_fine(:,2), q2_fine(:,3), q2_fine(:,4), '-', ...
    'Color', [colors.red, 0.9], 'LineWidth', 2.5, 'DisplayName', name2);

% --- 4. Mark start points (solid points and text) ---
% Plot Orbit 1 start point (purple circle)
plot3(q1_fine(1,2), q1_fine(1,3), q1_fine(1,4), 'o', ...
    'MarkerSize', 10, 'MarkerFaceColor', colors.purple, 'MarkerEdgeColor', 'w', ...
    'LineWidth', 1.5, 'HandleVisibility', 'off');
text(q1_fine(1,2), q1_fine(1,3), q1_fine(1,4), ' $t=0$', ...
    'Color', colors.purple, 'FontSize', 14, 'Interpreter', 'latex', ...
    'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left', 'FontWeight', 'bold');

% Plot Orbit 2 start point (green square)
plot3(q2_fine(1,2), q2_fine(1,3), q2_fine(1,4), 's', ...
    'MarkerSize', 10, 'MarkerFaceColor', colors.green, 'MarkerEdgeColor', 'w', ...
    'LineWidth', 1.5, 'HandleVisibility', 'off');
text(q2_fine(1,2), q2_fine(1,3), q2_fine(1,4), ' $t=0$', ...
    'Color', colors.green, 'FontSize', 14, 'Interpreter', 'latex', ...
    'VerticalAlignment', 'top', 'HorizontalAlignment', 'right', 'FontWeight', 'bold');
% --- 5. Add arrows ---
arrow_indices = round(linspace(1, 1000, 5)); 
arrow_indices = arrow_indices(2:4); 

add_flow_arrows_fixed_3(ax3, q1_fine, arrow_indices, colors.purple, 0.1);

add_flow_arrows_fixed_3(ax3, q2_fine, arrow_indices, colors.green, 0.1);

% --- 6. Add floor projection ---
z_all = [q1_fine(:,4); q2_fine(:,4)];
z_floor = min(z_all) - 0.5;

plot3(q1_fine(:,2), q1_fine(:,3), z_floor*ones(size(t_fine)), '-', 'Color', [colors.blue, 0.3], 'LineWidth', 1.5, 'HandleVisibility', 'off');
plot3(q2_fine(:,2), q2_fine(:,3), z_floor*ones(size(t_fine)), '-', 'Color', [colors.red, 0.3], 'LineWidth', 1.5, 'HandleVisibility', 'off');

% --- 7. Viewpoint and decoration ---
view(45, 30); 
xlabel('$q_1 (\mathbf{i})$'); ylabel('$q_2 (\mathbf{j})$'); zlabel('$q_3 (\mathbf{k})$');
title('\textbf{Figure 5.3. Topological Structure of Periodic Orbits}');
legend([p1, p2], 'Location', 'NorthEast', 'FontSize', 12, 'Interpreter', 'latex');
axis tight; set(gca, 'ZLim', [z_floor, max(z_all)+0.2]);
text(0, 0, z_floor, '\textbf{Shadow Projection}', 'Interpreter', 'latex', 'Color', colors.gray, 'HorizontalAlignment', 'center');

fig4 = figure('Position', [1050, 100, 600, 500], 'Color', 'w');
ax4 = axes('Position', [0.15, 0.15, 0.75, 0.75]);
hold(ax4, 'on'); axis(ax4, 'equal'); box(ax4, 'on');

% 1. Plot unit circle
theta = linspace(0, 2*pi, 300);
fill(cos(theta), sin(theta), [0.96 0.96 0.96], 'EdgeColor', 'k', 'LineStyle', '--');

% 2. Compute eigenvalues
eigs1 = kron(eig(M_A1), eig(M_B1));
eigs2 = kron(eig(M_A2), eig(M_B2));

% 3. Plot eigenvalues
% Orbit 1 -> Blue Dots
h_s = plot(real(eigs1), imag(eigs1), 'o', 'MarkerSize', 10, ...
    'MarkerFaceColor', colors.blue, 'MarkerEdgeColor', 'k', 'DisplayName', 'Multipliers of Orbit 1');
% Orbit 2 -> Red Squares
h_u = plot(real(eigs2), imag(eigs2), 's', 'MarkerSize', 10, ...
    'MarkerFaceColor', colors.red, 'MarkerEdgeColor', 'k', 'DisplayName', 'Multipliers of Orbit 2');

% 4. Decoration and axis settings
xlabel('Re($\lambda$)'); ylabel('Im($\lambda$)');
title('\textbf{Figure 5.4. Bilateral Floquet Spectrum}');
legend([h_s, h_u], 'Location', 'NorthEast'); 
grid on;

max_eig_norm = max([abs(eigs1); abs(eigs2); 1.2]);
axis_lim = max_eig_norm * 1.2; 
xlim([-axis_lim, axis_lim]);
ylim([-axis_lim, axis_lim]);

% 5. Dynamic logic determination and annotation
% --- Orbit 1 (Blue) Annotation ---
if rho1 < 1 - 1e-4
    status1_str = '< 1 \textbf{(Stable)}';
else
    status1_str = '> 1 \textbf{(Unstable)}';
end
text(1, -2.5, sprintf('$\\rho_1 \\approx %.4f %s$', rho1, status1_str), ...
    'Color', colors.blue, 'FontSize', 14, ...
    'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', ...
    'Interpreter', 'latex', 'BackgroundColor', 'w', 'EdgeColor', 'none');

% --- Orbit 2 (Red) Annotation ---
if rho2 < 1 - 1e-4
    status2_str = '< 1 \textbf{(Stable)}';
else
    status2_str = '> 1 \textbf{(Unstable)}';
end
text(0, axis_lim * 0.85, sprintf('$\\rho_2 \\approx %.4f %s$', rho2, status2_str), ...
    'Color', colors.red, 'FontSize', 14, ...
    'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
    'Interpreter', 'latex', 'BackgroundColor', 'w', 'EdgeColor', 'none');
text(0, -axis_lim * 0.85, sprintf('$\\rho_1 \\approx %.4f %s$', rho1, status1_str), ...
    'Color', colors.blue, 'FontSize', 14, ...
    'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', ...
    'Interpreter', 'latex', 'BackgroundColor', 'w', 'EdgeColor', 'none');
fprintf('[Visualization] Generating Figure 5.5 (Perturbation Evolution)...\n');

fig5 = figure('Position', [150, 150, 1000, 500], 'Color', 'w');

% --- Subplot 1: Perturbation of Stable Orbit (Orbit 1) ---
subplot(1, 2, 1); hold on; grid on; box on;
title('\textbf{(a) Stable Orbit Perturbation}', 'Interpreter', 'latex');
xlabel('$q_1$'); ylabel('$q_2$'); zlabel('$q_3$');
view(3);

% Plot reference orbit (Orbit 1)
plot3(q1_fine(:,2), q1_fine(:,3), q1_fine(:,4), 'k-', 'LineWidth', 2, 'DisplayName', 'Limit Cycle');

% Apply perturbation and integrate
perturbation_scale = 0.05; % Perturbation scale
num_perturbations = 8;     % Number of perturbations
t_span_pert = [0, T_period];

for k = 1:num_perturbations
    % Add random perturbation at the start point
    q0_pert = q1_mat(1,:)' + perturbation_scale * (rand(4,1)-0.5);
    [~, Y_pert] = ode45(@(t,y) riccati_rhs_3(t,y,a_fun,c_fun), t_span_pert, q0_pert);
    
    % Plot perturbation trajectories (blue scheme)
    plot3(Y_pert(:,2), Y_pert(:,3), Y_pert(:,4), '-', 'Color', [colors.blue, 0.6], 'LineWidth', 1);
end

% --- Subplot 2: Perturbation of Unstable Orbit (Orbit 2) ---
subplot(1, 2, 2); hold on; grid on; box on;
title('\textbf{(b) Unstable Orbit Perturbation}', 'Interpreter', 'latex');
xlabel('$q_1$'); ylabel('$q_2$'); zlabel('$q_3$');
view(3);

% Plot reference orbit (Orbit 2)
plot3(q2_fine(:,2), q2_fine(:,3), q2_fine(:,4), 'k-', 'LineWidth', 2, 'DisplayName', 'Limit Cycle');

% Apply perturbation and integrate
t_span_pert_unstable = [0, 30*T_period]; 

for k = 1:num_perturbations
    % Add random perturbation at the start point
    q0_pert = q2_mat(1,:)' + perturbation_scale * (rand(4,1)-0.5);
    [~, Y_pert] = ode45(@(t,y) riccati_rhs_3(t,y,a_fun,c_fun), t_span_pert_unstable, q0_pert);
    
    % Plot perturbation trajectories (red scheme)
    plot3(Y_pert(:,2), Y_pert(:,3), Y_pert(:,4), '-', 'Color', [colors.red, 0.6], 'LineWidth', 1);
end
fprintf('\n=== Step 6: Comparative Analysis (Q-CSCM vs. RK4 Shooting) ===\n');

% 1. Generate "Absolute Ground Truth"
% Use high-precision solution from Q-CSCM at N=100 as benchmark
fprintf('Generating Ground Truth (N=100)...\n');
N_truth = 100;
[x_true, D_true] = cheb_3(N_truth);
t_true = (x_true + 1) * T_period / 2;
D_glob_true = kron(D_true * dt_dtau, eye(4));

if ~exist('q1_mat', 'var')
    error('Please run Step 2 and Step 3 first to generate q1_mat');
end
q_guess_true = reshape(bary_interp_vector_3(q1_mat, t_nodes, t_true)', [], 1);

[Q_true_sol, conv_true] = newton_solver_robust_3(q_guess_true, D_glob_true, t_true, a_fun, c_fun);

if ~conv_true
    error('Cannot generate ground truth, please check parameters');
end
q0_exact = Q_true_sol(1:4); % Extract exact value at t=0 (this is our ground truth)

% ---------------------------------------------------------
% 2. Test Q-CSCM 
% ---------------------------------------------------------
fprintf('Testing Q-CSCM convergence...\n');
N_list = 8:4:100; % Sequence of node numbers
err_cscm = zeros(size(N_list));
dof_cscm = zeros(size(N_list));

for k = 1:length(N_list)
    n_k = N_list(k);
    [x_k, D_k] = cheb_3(n_k);
    t_k = (x_k + 1) * T_period / 2;
    D_glob_k = kron(D_k * dt_dtau, eye(4));
    
    % Initial guess
    q_guess_k = reshape(bary_interp_vector_3(q1_mat, t_nodes, t_k)', [], 1);
    [Q_k, conv_k] = newton_solver_robust_3(q_guess_k, D_glob_k, t_k, a_fun, c_fun);
    
    if conv_k
        % Compute distance to true solution
        err_cscm(k) = norm(Q_k(1:4) - q0_exact);
        dof_cscm(k) = 4 * (n_k + 1);
    else
        err_cscm(k) = NaN;
    end
end

% ---------------------------------------------------------
% 3. Test RK4 Shooting (Traditional Shooting Method)
% ---------------------------------------------------------
fprintf('Testing RK4 Shooting convergence...\n');
M_list = 100:50:1000; 
err_rk4 = zeros(size(M_list));
dof_rk4 = zeros(size(M_list));

% Increase precision requirements for fsolve
options = optimoptions('fsolve', 'Display', 'off', 'TolFun', 1e-16, 'TolX', 1e-16, 'MaxFunctionEvaluations', 20000);

for k = 1:length(M_list)
    steps = M_list(k);
    
    shooting_fun = @(q0) rk4_integrator_3(q0, T_period, steps, a_fun, c_fun) - q0;
    
    [q0_rk4, ~, exitflag] = fsolve(shooting_fun, q0_exact, options);
    
    if exitflag > 0
        err_rk4(k) = norm(q0_rk4 - q0_exact);
        dof_rk4(k) = 4 * steps; 
    else
        err_rk4(k) = NaN;
    end
end

% ---------------------------------------------------------
% 4. Plotting (The "Killer Plot")
% ---------------------------------------------------------
fig6 = figure('Position', [200, 200, 700, 500], 'Color', 'w');
ax6 = axes('Position', [0.15, 0.15, 0.75, 0.75]);

% Plot Q-CSCM
loglog(dof_cscm, err_cscm + 1e-16, 'o-', 'Color', colors.blue, 'LineWidth', 2, ...
    'MarkerSize', 8, 'MarkerFaceColor', colors.blue, 'DisplayName', '\textbf{Proposed Q-CSCM}');

hold on;

% Plot RK4
loglog(dof_rk4, err_rk4 + 1e-16, 's--', 'Color', colors.red, 'LineWidth', 2, ...
    'MarkerSize', 8, 'MarkerFaceColor', colors.red, 'DisplayName', 'RK4 Shooting ($O(h^4)$)');

% Add auxiliary line
yline(1e-15, 'k:', 'Machine Epsilon', 'LineWidth', 1.5, 'HandleVisibility', 'off');

grid on; box on;
xlabel('\textbf{Degrees of Freedom (Computational Cost)}', 'Interpreter', 'latex');
ylabel('\textbf{Error} $\|q_0 - q_{exact}\|$', 'Interpreter', 'latex');
title('\textbf{Figure 5.6. Convergence Comparison}', 'Interpreter', 'latex');
legend('Location', 'SouthWest', 'Interpreter', 'latex', 'FontSize', 12);

% Annotation
text(50, 1e-12, '\textbf{Spectral Convergence}', 'Color', colors.blue, 'Interpreter', 'latex', 'FontSize', 12);
text(1000, 1e-7, '\textbf{Algebraic Decay}', 'Color', colors.red, 'Interpreter', 'latex', 'FontSize', 12);

xlim([min(dof_cscm)*0.8, max(dof_rk4)*1.2]);
ylim([1e-16, 1e0]);

fprintf('Comparison plot generated.\n');