function out = qmult_3(q, p)
    out = get_chi_3(q, 'L') * p;
end

