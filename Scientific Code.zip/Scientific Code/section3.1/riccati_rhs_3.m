function dq = riccati_rhs_3(t, q, a_fun, c_fun)
    av = a_fun(t)'; cv = c_fun(t)';
    qa = qmult_3(q, av);
    dq = qmult_3(qa, q) + cv;
end

