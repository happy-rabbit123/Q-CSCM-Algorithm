function M = compute_monodromy_3(T, Coeff_Fun, side)
    M = eye(4);
    for i=1:4
        y0 = zeros(4,1); y0(i)=1;
        if strcmp(side, 'L')
            f = @(t,y) get_chi_3(Coeff_Fun(t), 'L') * y;
        else
            f = @(t,y) get_chi_3(Coeff_Fun(t), 'R')' * y;
        end
        [~, Y] = ode45(f, [0, T], y0);
        M(:,i) = Y(end,:)';
    end
end