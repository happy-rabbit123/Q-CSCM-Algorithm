function q_end = rk4_integrator_3(q0, T, steps, a_fun, c_fun)
    dt = T / steps;
    q = q0;
    t = 0;
    for i = 1:steps
        % k1
        av = a_fun(t)'; cv = c_fun(t)';
        qa = get_chi_3(q, 'L') * av;
        k1 = get_chi_3(qa, 'L') * q + cv;
        
        % k2
        tm = t + 0.5*dt; qm = q + 0.5*dt*k1;
        av = a_fun(tm)'; cv = c_fun(tm)';
        qa = get_chi_3(qm, 'L') * av;
        k2 = get_chi_3(qa, 'L') * qm + cv;
        
        % k3
        qm = q + 0.5*dt*k2;
        % av, cv same as k2
        qa = get_chi_3(qm, 'L') * av;
        k3 = get_chi_3(qa, 'L') * qm + cv;
        
        % k4
        tn = t + dt; qn = q + dt*k3;
        av = a_fun(tn)'; cv = c_fun(tn)';
        qa = get_chi_3(qn, 'L') * av;
        k4 = get_chi_3(qa, 'L') * qn + cv;
        
        q = q + (dt/6) * (k1 + 2*k2 + 2*k3 + k4);
        t = t + dt;
    end
    q_end = q;
end