function d = diff_c_3(v, idx)
    d = v(idx+1) - v(idx);
end

