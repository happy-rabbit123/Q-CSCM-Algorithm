function M = compute_monodromy_qcscm_2(N, T, A_fun, B_fun)
    % Construct Chebyshev differentiation matrix
    [x, D] = cheb_diff_2(N);
    dt_dtau = 2/T; 
    D = D * dt_dtau; % Differentiation matrix in physical domain
    
    % Construct fully discrete system matrix (Kronecker Product)
    % Equation: dot{Q} - AQ - QB = 0
    % Vectorization: (D_global - M_global) * vec(Q) = 0
    
    t_nodes = (x + 1) * T/2; % Physical time nodes
    
    % Construct block diagonal matrix M_L (containing A_L + B_R^T)
    M_blocks = cell(N+1, 1);
    for i = 1:N+1
        ti = t_nodes(i);
        Ai = A_fun(ti); 
        Bi = B_fun(ti);
        
        AL = get_chi_2(Ai, 'L');
        BR = get_chi_2(Bi, 'R');
        
        % Core operator: A_L + B_R^T
        M_blocks{i} = AL + BR'; 
    end
    M_global = blkdiag(M_blocks{:});
    
    D_global = kron(D, eye(4));
    Sys = D_global - M_global;
    
    % Apply initial conditions (t=0 corresponds to Chebyshev node x=-1, index N+1)
    idx_init = 4*N + (1:4); 
    Sys(idx_init, :) = 0;
    Sys(idx_init, idx_init) = eye(4);
    
    % Solve 4 initial value problems to construct the monodromy matrix
    M = zeros(4,4);
    for col = 1:4
        rhs = zeros(4*(N+1), 1);
        e0 = zeros(4,1); e0(col) = 1;
        rhs(idx_init) = e0; % Initial value
        
        Q_vec = Sys \ rhs;
        
        % Extract value at t=T (corresponds to Chebyshev node x=1, index 1)
        M(:, col) = Q_vec(1:4);
    end
end