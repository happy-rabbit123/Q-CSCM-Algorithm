function [x, D] = cheb_diff_2(N)
    % Classic Chebyshev spectral differentiation matrix generator (Trefethen)
    % Input: N (truncation order)
    % Output: x (Gauss-Lobatto nodes), D (differentiation matrix)
    
    if N==0, x=1; D=0; return; end
    x = cos(pi*(0:N)/N)';
    c = [2; ones(N-1,1); 2].*(-1).^(0:N)';
    X = repmat(x,1,N+1);
    dX = X-X';
    D  = (c*(1./c)')./(dX+(eye(N+1)));      % Off-diagonal entries
    D  = D - diag(sum(D'));                 % Diagonal entries (using the property that row sums are zero)
end