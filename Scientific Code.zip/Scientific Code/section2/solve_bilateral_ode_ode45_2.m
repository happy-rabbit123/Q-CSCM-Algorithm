function [t, q] = solve_bilateral_ode_ode45_2(t_span, A_fun, B_fun, q0, options)
    get_AL = @(q) [q(1) -q(2) -q(3) -q(4); q(2) q(1) -q(4) q(3); q(3) q(4) q(1) -q(2); q(4) -q(3) q(2) q(1)];
    get_BR = @(q) [q(1) -q(2) -q(3) -q(4); q(2) q(1) q(4) -q(3); q(3) -q(4) q(1) q(2); q(4) q(3) -q(2) q(1)];
    
    sys_fun = @(t, y) (get_AL(A_fun(t)) + get_BR(B_fun(t))') * y; 
    
    [t, q] = ode45(sys_fun, t_span, q0, options);
end
