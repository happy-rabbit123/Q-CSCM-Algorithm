clear; clc; close all;

% --- 1. Global Aesthetic Settings ---
colors.blue   = [0.00, 0.45, 0.74];
colors.red    = [0.85, 0.33, 0.10];
colors.yellow = [0.93, 0.69, 0.13];
colors.purple = [0.49, 0.18, 0.56];
colors.green  = [0.47, 0.67, 0.19];
colors.gray   = [0.50, 0.50, 0.50]; % Correct spelling

set(0, 'DefaultTextInterpreter', 'latex');
set(0, 'DefaultLegendInterpreter', 'latex');
set(0, 'DefaultAxesTickLabelInterpreter', 'latex');
set(0, 'DefaultAxesFontSize', 14); 
set(0, 'DefaultLineLineWidth', 2); 
set(0, 'DefaultAxesLineWidth', 1.2);
set(0, 'DefaultAxesBox', 'on');

%% --- Experiment A: Parametric Floquet Analysis ---
fprintf('Generating Figure 2: Floquet Analysis (using Q-CSCM)...\n');

mu_vals = 0.4:0.02:0.85; 
T_period = 2*pi;
rho_list = zeros(size(mu_vals));
eig_traj = cell(length(mu_vals), 1);

% Q-CSCM parameters
N_spectral = 24; % Spectral truncation order

% Compute data
for k = 1:length(mu_vals)
    mu = mu_vals(k);
    A_fun = @(t) [0, mu*sin(t), 0, 0.5]; 
    B_fun = @(t) [mu-0.6, 0, cos(t), 0]; 
    
    M_mono = compute_monodromy_qcscm_2(N_spectral, T_period, A_fun, B_fun);
    
    eigs = eig(M_mono);
    eig_traj{k} = eigs;
    rho_list(k) = max(abs(eigs));
end

% --- Create Figure 2 ---
fig2 = figure('Position', [100, 100, 1200, 550], 'Color', 'w');
t = tiledlayout(1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

% === Subplot 1: Complex Plane Trajectory ===
nexttile; hold on; axis equal;
% 1. Plot unit circle
theta = linspace(0, 2*pi, 300);
fill(cos(theta), sin(theta), [0.92 0.96 1.0], 'EdgeColor', colors.blue, ...
    'LineStyle', '--', 'LineWidth', 1, 'FaceAlpha', 0.3); 
% 2. Plot coordinate axes
plot([-1.8 1.8], [0 0], 'Color', [0.7 0.7 0.7], 'LineWidth', 1);
plot([0 0], [-1.8 1.8], 'Color', [0.7 0.7 0.7], 'LineWidth', 1);

% 3. Plot trajectories
cmap = jet(length(mu_vals));
for k = 1:length(mu_vals)
    plot(real(eig_traj{k}), imag(eig_traj{k}), 'o', ...
        'MarkerSize', 6, 'MarkerFaceColor', cmap(k,:), 'MarkerEdgeColor', 'none');
end

% Colorbar
c = colorbar;
c.Label.String = 'Parameter $\mu$';
c.Label.Interpreter = 'latex';
c.Label.FontSize = 12;

xlabel('Real Part $\mathrm{Re}(\lambda)$');
ylabel('Imaginary Part $\mathrm{Im}(\lambda)$');
title('\textbf{(a) Spectral Flow on Complex Plane}');
xlim([-1.6, 1.6]); ylim([-1.6, 1.6]);
text(0, 0, '\textbf{Stable}', 'Color', colors.blue, 'HorizontalAlignment', 'center', 'FontSize', 12);

% === Subplot 2: Bifurcation Analysis ===
nexttile; hold on; box on;
% 1. Plot background regions
x_lims = [min(mu_vals), max(mu_vals)];
fill([x_lims(1) x_lims(2) x_lims(2) x_lims(1)], [0 0 1 1], ...
    [0.92 0.96 1.0], 'EdgeColor', 'none', 'FaceAlpha', 0.3); 
fill([x_lims(1) x_lims(2) x_lims(2) x_lims(1)], [1 1 4 4], ...
    [1.0 0.92 0.92], 'EdgeColor', 'none', 'FaceAlpha', 0.3); 

% 2. Plot curve
plot(mu_vals, rho_list, 'b-s', 'LineWidth', 2, 'MarkerFaceColor', 'b', 'MarkerSize', 6);

% 3. Auxiliary lines
yline(1, '--', 'Color', colors.red, 'LineWidth', 2);
[~, idx_c] = min(abs(rho_list - 1));
plot(mu_vals(idx_c), rho_list(idx_c), 'p', 'MarkerSize', 16, 'MarkerFaceColor', colors.yellow, 'MarkerEdgeColor', 'k');

xlabel('Parameter $\mu$');
ylabel('Spectral Radius $\rho(\mathcal{M})$');
title('\textbf{(b) Bifurcation \& Criticality}'); 
ylim([0, 3.5]); xlim(x_lims);

%% --- Experiment B: Scalar-Vector Separation (Figure 3) ---
fprintf('Generating Figure 3: Structure Preservation...\n');

T_end = 12;
t_fine = linspace(0, T_end, 800);
alpha_t = @(t) -0.5 + 0.2*sin(t);
beta_t  = @(t) -0.3;
A_rot = @(t) [alpha_t(t), 100*sin(t.^2), 0, 0];
B_rot = @(t) [beta_t(t), 0, 50*cos(t), 0];

% Compute theoretical bound
theoretical_bound = zeros(size(t_fine));
for i = 1:length(t_fine)
    % Integral: -0.8t - 0.2cos(t) + 0.2
    val = (-0.8*t_fine(i) - 0.2*cos(t_fine(i))) - (-0.2);
    theoretical_bound(i) = exp(val);
end

% Compute numerical solution
q0 = [1; 0; 0; 0]; 
options = odeset('RelTol', 1e-10, 'AbsTol', 1e-12);
[t_sol, q_sol] = solve_bilateral_ode_ode45_2(t_fine, A_rot, B_rot, q0, options);
q_norm = vecnorm(q_sol, 2, 2); 

% --- Create Figure 3 ---
fig3 = figure('Position', [150, 150, 900, 500], 'Color', 'w');
ax_main = axes('Position', [0.1, 0.12, 0.85, 0.8]); 
hold(ax_main, 'on'); box(ax_main, 'on');

% 1. Plot main curves
p1 = semilogy(ax_main, t_fine, q_norm, '-', 'Color', [colors.blue, 0.6], 'LineWidth', 4, ...
    'DisplayName', 'Numerical Solution $\|\mathbf{q}(t)\|$');
p2 = semilogy(ax_main, t_fine, theoretical_bound, '--', 'Color', colors.red, 'LineWidth', 2, ...
    'DisplayName', 'Theoretical Bound (Thm 3.5)');

% 2. Customize main axes
grid(ax_main, 'on');
ax_main.GridAlpha = 0.15; 
xlabel(ax_main, 'Time $t$');
ylabel(ax_main, 'Energy Norm (log scale)');
title(ax_main, '\textbf{Verification of Scalar-Vector Separation Principle}');
legend(ax_main, [p1, p2], 'Location', 'SouthWest', 'FontSize', 12, 'Box', 'off');

% 3. Create advanced inset
ax_inset = axes('Position', [0.55, 0.55, 0.32, 0.3]); 
box(ax_inset, 'on'); hold(ax_inset, 'on');
% Extract data for the first 2 seconds to show oscillations
idx_zoom = t_sol <= 2;
plot(ax_inset, t_sol(idx_zoom), q_sol(idx_zoom, 2), '-', 'Color', colors.green, 'LineWidth', 1);
set(ax_inset, 'Color', [0.98 0.98 0.98]); 
title(ax_inset, 'Vector Component $q_1(t)$', 'FontSize', 11);
xlabel(ax_inset, 'Micro-scale Time');
set(ax_inset, 'YTickLabel', []); 
axis(ax_inset, 'tight');

% 4. Add arrows and annotations
annotation('arrow', [0.54, 0.42], [0.55, 0.40], 'Color', colors.gray, 'LineWidth', 1.5);
annotation('textbox', [0.33, 0.49, 0.2, 0.1], ...
    'String', {'\textbf{Chaos inside,}', '\textbf{Order outside}'}, ...
    'Interpreter', 'latex', ...
    'Color', colors.gray, ...
    'FontSize', 13, ...
    'EdgeColor', 'none', ... 
    'HorizontalAlignment', 'left', ...
    'VerticalAlignment', 'middle');