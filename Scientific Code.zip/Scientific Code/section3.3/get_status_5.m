function s = get_status_5(rho)
    if rho < 1 - 1e-4
        s = 'Stable';
    else
        s = 'Unstable';
    end
end