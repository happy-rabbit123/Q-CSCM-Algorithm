function q_interp = bary_interp_vector_5(q_nodes, t_nodes, t_query)
    % q_nodes: (N+1) x 4 quaternion values at nodes
    % t_nodes: (N+1) x 1 node times
    % t_query: M x 1 query times
    % q_interp: M x 4 interpolation results
    
    % Use barycentric interpolation formula (Barycentric Interpolation)
    n = length(t_nodes) - 1;
    % Chebyshev barycentric weights
    w = [0.5; ones(n-1,1); 0.5] .* (-1).^(0:n)';
    
    M = length(t_query);
    q_interp = zeros(M, 4);
    
    % Interpolate the 4 components of the quaternion separately
    for k = 1:4
        vals = q_nodes(:, k);
        
        % Vectorized barycentric interpolation
        numer = zeros(M, 1);
        denom = zeros(M, 1);
        exact = false(M, 1);
        
        for j = 1:n+1
            diff = t_query - t_nodes(j);
            % Handle cases where t_query coincides with nodes
            mask = abs(diff) < 1e-14;
            if any(mask)
                q_interp(mask, k) = vals(j);
                exact = exact | mask;
            end
            
            % Avoid division by zero; compute for non-node points
            temp = w(j) ./ diff;
            temp(mask) = 0; 
            
            numer = numer + temp * vals(j);
            denom = denom + temp;
        end
        
        valid = ~exact;
        q_interp(valid, k) = numer(valid) ./ denom(valid);
    end
end