function [Q, converged] = newton_solver_general_5(Q_guess, D_global, A_val, B_val, C_val, D_val)
    % A_val, B_val, C_val, D_val: (N+1)x4 arrays of coefficients at nodes
    % Equation: q_dot - (q*a*q + b*q + q*d + c) = 0
    
    Q = Q_guess;
    max_iter = 20;
    tol = 1e-10;
    converged = false;
    N = size(A_val, 1) - 1;
    
    for iter = 1:max_iter
        % 1. Construct residual F
        Q_mat = reshape(Q, 4, [])'; % (N+1)x4
        dQ = reshape(D_global * Q, 4, [])';
        
        % Compute nonlinear term q*a*q
        qa = qmult_vec_5(Q_mat, A_val);
        qaq = qmult_vec_5(qa, Q_mat);
        
        % Compute linear terms b*q and q*d
        bq = qmult_vec_5(B_val, Q_mat);
        qd = qmult_vec_5(Q_mat, D_val);
        
        % Residual vector
        Res_mat = dQ - (qaq + bq + qd + C_val);
        F = reshape(Res_mat', [], 1);
        
        % Check convergence
        res_norm = norm(F, inf);
        if res_norm < tol
            converged = true;
            fprintf('Converged in %d iterations. Residual: %.4e\n', iter, res_norm);
            return;
        end
        
        % 2. Construct Jacobian matrix
        % Linearization: delta_q_dot - [ (q*a + b)*delta_q + delta_q*(a*q + d) ]
        
        % Compute derivative coefficients
        L_coeff = qa + B_val; % Left multiplier: q*a + b
        R_coeff = qmult_vec_5(A_val, Q_mat) + D_val; % Right multiplier: a*q + d
        
        % Construct block diagonal matrices
        Blk_L = cell(N+1, 1);
        Blk_R = cell(N+1, 1);
        
        for k = 1:N+1
            % Left multiplication matrix representation M_L(u) * x
            Blk_L{k} = qmatL_5(L_coeff(k,:));
            % Right multiplication matrix representation M_R(v) * x
            Blk_R{k} = qmatR_5(R_coeff(k,:));
        end
        
        J_alg = blkdiag(Blk_L{:}) + blkdiag(Blk_R{:});
        
        % Total Jacobian matrix
        Jac = D_global - J_alg;
        
        % 3. Apply periodic boundary conditions (q(0) = q(T))
        % Replace the last row block with I, 0, ..., 0, -I
        row_idx = 4*N+1 : 4*(N+1);
        col_idx_start = 1:4;
        col_idx_end = 4*N+1 : 4*(N+1);
        
        Jac(row_idx, :) = 0;
        Jac(row_idx, col_idx_start) = eye(4);
        Jac(row_idx, col_idx_end) = -eye(4);
        F(row_idx) = Q(col_idx_start) - Q(col_idx_end);
        
        % 4. Update
        delta = Jac \ (-F);
        Q = Q + delta;
    end
    fprintf('Max iterations reached. Residual: %.4e\n', res_norm);
end