function rho = get_spectral_radius_5(T, A_fun, B_fun)
    % Calculate the spectral radius of the bilateral system
    % A_fun, B_fun: Function handles, input t, output 1x4 quaternion
    
    % 1. Compute the left monodromy matrix M_A
    [~, Phi_A] = ode45(@(t, y) reshape(qmatL_5(A_fun(t)) * reshape(y,4,4), [], 1), ...
                       [0, T], reshape(eye(4), [], 1));
    M_A = reshape(Phi_A(end,:), 4, 4);
    
    % 2. Compute the right monodromy matrix M_B (Note: right multiplication is x*B -> corresponding matrix is qmatR(B))
    [~, Phi_B] = ode45(@(t, y) reshape(qmatR_5(B_fun(t)) * reshape(y,4,4), [], 1), ...
                       [0, T], reshape(eye(4), [], 1));
    M_B = reshape(Phi_B(end,:), 4, 4);
    
    % 3. Spectral radius = rho(M_A) * rho(M_B)
    rho = max(abs(eig(M_A))) * max(abs(eig(M_B)));
end