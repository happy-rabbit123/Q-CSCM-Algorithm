function add_projections_5(ax, q_data)
    x = q_data(:,2); y = q_data(:,3); z = q_data(:,4);
    
    % Get current axis limits
    xlims = [min(x), max(x)]; ylims = [min(y), max(y)]; zlims = [min(z), max(z)];
    range = max([diff(xlims), diff(ylims), diff(zlims)]);
    margin = range * 0.2;
    
    % Set projection plane positions (Bottom and back of the box)
    x_wall = xlims(2) + margin;
    y_wall = ylims(2) + margin;
    z_floor = zlims(1) - margin;
    
    % Plot projections (gray lines)
    plot3(ax, x, y, z_floor * ones(size(z)), '-', 'Color', [0.8 0.8 0.8], 'LineWidth', 1); % Bottom plane (xy)
    plot3(ax, x, y_wall * ones(size(y)), z, '-', 'Color', [0.8 0.8 0.8], 'LineWidth', 1); % Side plane (xz)
    plot3(ax, x_wall * ones(size(x)), y, z, '-', 'Color', [0.8 0.8 0.8], 'LineWidth', 1); % Side plane (yz)
    
    % Slightly expand axes to accommodate projections
    axis(ax, 'tight');
    set(ax, 'Box', 'on');
end