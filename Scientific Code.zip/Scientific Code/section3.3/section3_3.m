clear; clc; close all;

% --- Global Settings ---
colors.blue   = [0.00, 0.447, 0.741];
colors.red    = [0.850, 0.325, 0.098];
set(0, 'DefaultTextInterpreter', 'latex');
set(0, 'DefaultAxesFontSize', 12);

T_period = 2*pi;

q_i = [0, 1, 0, 0];
q_exp_jt = @(t) [cos(t), zeros(size(t)), sin(t), zeros(size(t))]; % e^{jt}
q_exp_kt = @(t) [cos(t), zeros(size(t)), zeros(size(t)), sin(t)]; % e^{kt}


a_fun = @(t) repmat(q_i, size(t,1), 1);

% eta(t) = -(10i + e^{kt})
eta_fun = @(t) -([zeros(size(t)), 10*ones(size(t)), zeros(size(t)), zeros(size(t))] + q_exp_kt(t));

% xi(t) = e^{jt}
xi_fun = @(t) q_exp_jt(t);

% d(t) = -i * eta(t) (Right multiplication coefficient)
d_fun = @(t) -qmult_vec_5(a_fun(t), eta_fun(t));

% b(t) = -xi(t) * i (Left multiplication coefficient)
b_fun = @(t) -qmult_vec_5(xi_fun(t), a_fun(t));

% c(t) = xi(t) * i * eta(t) + 1
c_fun = @(t) qmult_vec_5(qmult_vec_5(xi_fun(t), a_fun(t)), eta_fun(t)) + [ones(size(t)), zeros(size(t)), zeros(size(t)), zeros(size(t))];

N = 40; % Number of nodes
[x, D] = cheb_5(N);
dt_dtau = 2/T_period;
D_global = kron(D * dt_dtau, eye(4));
t_nodes = (x + 1) * T_period / 2;

% Compute coefficient matrices at nodes
A_val = a_fun(t_nodes);
B_val = b_fun(t_nodes);
C_val = c_fun(t_nodes);
D_val = d_fun(t_nodes);

% Guess 1: q ~ xi(t)
Q_guess1 = reshape(xi_fun(t_nodes)', [], 1);

% Guess 2: q ~ eta(t)
Q_guess2 = reshape(eta_fun(t_nodes)', [], 1);

fprintf('Solving for Orbit 1 (Small Amplitude)...\n');
[Q_sol1, conv1] = newton_solver_general_5(Q_guess1, D_global, A_val, B_val, C_val, D_val);

fprintf('Solving for Orbit 2 (Large Amplitude)...\n');
[Q_sol2, conv2] = newton_solver_general_5(Q_guess2, D_global, A_val, B_val, C_val, D_val);

if ~conv1 || ~conv2
    error('Newton solver failed to converge.');
end

q1_mat = reshape(Q_sol1, 4, [])';
q2_mat = reshape(Q_sol2, 4, [])';

% Construction of linearization coefficients
% A_lin (Left multiplication) = q*a + b
% B_lin (Right multiplication) = a*q + d

% Orbit 1
A_lin1 = @(t) qmult_vec_5(bary_interp_vector_5(q1_mat, t_nodes, t), a_fun(t)) + b_fun(t);
B_lin1 = @(t) qmult_vec_5(a_fun(t), bary_interp_vector_5(q1_mat, t_nodes, t)) + d_fun(t);
rho1 = get_spectral_radius_5(T_period, A_lin1, B_lin1);

% Orbit 2
A_lin2 = @(t) qmult_vec_5(bary_interp_vector_5(q2_mat, t_nodes, t), a_fun(t)) + b_fun(t);
B_lin2 = @(t) qmult_vec_5(a_fun(t), bary_interp_vector_5(q2_mat, t_nodes, t)) + d_fun(t);
rho2 = get_spectral_radius_5(T_period, A_lin2, B_lin2);

fprintf('\n=== Results for Example 7 ===\n');
fprintf('Orbit 1: rho = %.4e (%s)\n', rho1, get_status_5(rho1));
fprintf('Orbit 2: rho = %.4e (%s)\n', rho2, get_status_5(rho2));

figure('Position', [100, 100, 1000, 500], 'Color', 'w');

% 3D Phase Portrait
subplot(1, 2, 1); hold on; grid on; axis equal; view(3);
plot3(q1_mat(:,2), q1_mat(:,3), q1_mat(:,4), 'b-', 'LineWidth', 2);
plot3(q2_mat(:,2), q2_mat(:,3), q2_mat(:,4), 'r-', 'LineWidth', 2);
xlabel('$q_1 (\mathbf{i})$', 'Interpreter', 'latex');
ylabel('$q_2 (\mathbf{j})$', 'Interpreter', 'latex');
zlabel('$q_3 (\mathbf{k})$', 'Interpreter', 'latex');
title('\textbf{3D Phase Portrait}', 'Interpreter', 'latex');
legend({sprintf('Orbit 1 ($\\rho \\approx %.1e$)', rho1), ...
        sprintf('Orbit 2 ($\\rho \\approx %.1e$)', rho2)}, ...
        'Location', 'best', 'Interpreter', 'latex');

% Norm evolution over time
subplot(1, 2, 2); hold on; grid on;
t_plot = linspace(0, 2*pi, N+1);
plot(t_plot, sqrt(sum(q1_mat.^2, 2)), 'b-o', 'LineWidth', 1.5, 'MarkerSize', 4);
plot(t_plot, sqrt(sum(q2_mat.^2, 2)), 'r-s', 'LineWidth', 1.5, 'MarkerSize', 4);
xlabel('$t$', 'Interpreter', 'latex');
ylabel('$|q(t)|$', 'Interpreter', 'latex');
title('\textbf{Norm Evolution}', 'Interpreter', 'latex');
legend({'Orbit 1', 'Orbit 2'}, 'Interpreter', 'latex');
if ~exist('q1_mat', 'var') || ~exist('q2_mat', 'var')
    error('Please run the main solver first to generate q1_mat and q2_mat');
end

% 1. Data interpolation
t_fine = linspace(0, 2*pi, 500)';
q1_fine = bary_interp_vector_5(q1_mat, t_nodes, t_fine);
q2_fine = bary_interp_vector_5(q2_mat, t_nodes, t_fine);

% 2. Create figure
figure('Position', [100, 100, 1200, 500], 'Color', 'w');
t = tiledlayout(1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

% --- Subplot 1: Stable Orbit (Orbit 1) ---
ax1 = nexttile;
hold(ax1, 'on'); grid(ax1, 'on'); axis(ax1, 'equal'); view(ax1, 3);
title(ax1, '\textbf{(a) Stable Orbit (Zoomed)}', 'Interpreter', 'latex', 'FontSize', 14);

% Plotting
plot_4d_trajectory_5(ax1, q1_fine);
add_projections_5(ax1, q1_fine);

% Decoration
xlabel(ax1, '$q_1 (\mathbf{i})$', 'Interpreter', 'latex');
ylabel(ax1, '$q_2 (\mathbf{j})$', 'Interpreter', 'latex');
zlabel(ax1, '$q_3 (\mathbf{k})$', 'Interpreter', 'latex');

colormap(ax1, 'parula'); 
c1 = colorbar(ax1);
drawnow limitrate; 
c1.Label.String = 'Scalar Part $q_0(t)$';
c1.Label.Interpreter = 'latex';
c1.Label.FontSize = 12;

% --- Subplot 2: Unstable Orbit (Orbit 2) ---
ax2 = nexttile;
hold(ax2, 'on'); grid(ax2, 'on'); axis(ax2, 'equal'); view(ax2, 3);
title(ax2, '\textbf{(b) Unstable Orbit (Zoomed)}', 'Interpreter', 'latex', 'FontSize', 14);

% Plotting
plot_4d_trajectory_5(ax2, q2_fine);
add_projections_5(ax2, q2_fine);

% Decoration
xlabel(ax2, '$q_1 (\mathbf{i})$', 'Interpreter', 'latex');
ylabel(ax2, '$q_2 (\mathbf{j})$', 'Interpreter', 'latex');
zlabel(ax2, '$q_3 (\mathbf{k})$', 'Interpreter', 'latex');

colormap(ax2, 'turbo'); 
c2 = colorbar(ax2);
drawnow limitrate;
c2.Label.String = 'Scalar Part $q_0(t)$';
c2.Label.Interpreter = 'latex';
c2.Label.FontSize = 12;