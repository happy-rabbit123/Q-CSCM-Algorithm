function plot_4d_trajectory_5(ax, q_data)
    % q_data: Nx4 matrix [q0, q1, q2, q3]
    x = q_data(:,2); % i
    y = q_data(:,3); % j
    z = q_data(:,4); % k
    c = q_data(:,1); % scalar part as color
    
    % Use surface to draw gradient colored lines (more advanced than plot3)
    % Technique: Construct a strip surface but only display edges
    surface(ax, [x, x], [y, y], [z, z], [c, c], ...
        'FaceColor', 'no', ...
        'EdgeColor', 'interp', ...
        'LineWidth', 3);
    
    % Mark the starting point
    plot3(ax, x(1), y(1), z(1), 'ko', 'MarkerFaceColor', 'w', 'MarkerSize', 8, 'LineWidth', 1.5);
    text(ax, x(1), y(1), z(1), ' $t=0$', 'Interpreter', 'latex', 'FontSize', 12, 'VerticalAlignment', 'bottom');
end