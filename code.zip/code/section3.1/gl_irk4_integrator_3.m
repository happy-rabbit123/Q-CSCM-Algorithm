%% ========================================================================
% HELPER FUNCTION: Gauss-Legendre IRK4 Integrator for Nonlinear Riccati
% =========================================================================
function q_end = gl_irk4_integrator_3(q0, T, steps, a_fun, c_fun)
    % 4th-order Symplectic Gauss-Legendre Implicit Runge-Kutta
    h = T / steps;
    t_grid = linspace(0, T, steps+1);
    
    % Butcher Tableau
    c1 = 0.5 - sqrt(3)/6; c2 = 0.5 + sqrt(3)/6;
    a11 = 0.25; a12 = 0.25 - sqrt(3)/6; 
    a21 = 0.25 + sqrt(3)/6; a22 = 0.25;
    b1 = 0.5; b2 = 0.5;
    
    q = q0;
    for n = 1:steps
        tn = t_grid(n);
        % Initial guess for stages using explicit evaluation
        k1 = riccati_rhs_3(tn, q, a_fun, c_fun);
        k2 = k1;
        
        % Fixed-point iteration to solve implicit non-linear stage equations
        % (Converges rapidly due to small step size h)
        for iter = 1:50
            q1 = q + h*(a11*k1 + a12*k2);
            q2 = q + h*(a21*k1 + a22*k2);
            
            k1_new = riccati_rhs_3(tn + c1*h, q1, a_fun, c_fun);
            k2_new = riccati_rhs_3(tn + c2*h, q2, a_fun, c_fun);
            
            if max(norm(k1_new - k1), norm(k2_new - k2)) < 1e-13
                k1 = k1_new; k2 = k2_new;
                break;
            end
            k1 = k1_new; k2 = k2_new;
        end
        % Update step
        q = q + h*(b1*k1 + b2*k2);
    end
    q_end = q;
end