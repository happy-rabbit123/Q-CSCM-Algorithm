clear; clc; close all;
% --- 1. Global Aesthetic Settings ---
colors.blue   = [0.00, 0.447, 0.741];
colors.red    = [0.850, 0.325, 0.098];
colors.purple = [0.494, 0.184, 0.556];
colors.green  = [0.466, 0.674, 0.188];
colors.gray   = [0.6, 0.6, 0.6];
set(0, 'DefaultTextInterpreter', 'latex');
set(0, 'DefaultLegendInterpreter', 'latex');
set(0, 'DefaultAxesFontSize', 14);
set(0, 'DefaultLineLineWidth', 1.5);
set(0, 'DefaultAxesBox', 'on');
set(0, 'DefaultAxesLineWidth', 1.2);

%% --- Step 1: Problem Definition (The "Twisted" Oscillator) ---
T_period = 2*pi;
% Coefficient definition [q0, q1, q2, q3]
a_fun = @(t) [-0.5, cos(t), 0.3*sin(t), 0];
c_fun = @(t) [-0.1, 0, 0, 0.2*cos(2*t)];
% Q-CSCM parameters
N = 40; 
[x, D] = cheb_3(N); 
dt_dtau = 2/T_period; 
D_global = kron(D * dt_dtau, eye(4));
t_nodes = (x + 1) * T_period / 2;

fprintf('Solving Complex Riccati Dynamics...\n');
% Strategy: Generate initial trajectory using ODE45 (IVP -> BVP)
% Orbit 1: Start from small initial value
[~, q_init1] = ode45(@(t,y) riccati_rhs_3(t,y,a_fun,c_fun), t_nodes, [0.05;0;0;0]);
Q_guess1 = reshape(q_init1', [], 1);
% Orbit 2: Start from large initial value
[~, q_init2] = ode45(@(t,y) riccati_rhs_3(t,y,a_fun,c_fun), t_nodes, [0;0.8;0.8;0.8]);
Q_guess2 = reshape(q_init2', [], 1);

% Newton iteration
[Q_sol1, conv1] = newton_solver_robust_3(Q_guess1, D_global, t_nodes, a_fun, c_fun);
[Q_sol2, conv2] = newton_solver_robust_3(Q_guess2, D_global, t_nodes, a_fun, c_fun);
if ~conv1 || ~conv2
    error('Solver failed. Please check initial guesses or system parameters.');
end

fprintf('\nStep 3: Stability Analysis (Dynamic Check)...\n');
% Extract solution matrices
q1_mat = reshape(Q_sol1, 4, [])';
q2_mat = reshape(Q_sol2, 4, [])';

% --- Analyze Orbit 1 ---
A_stab1 = @(t) qmult_3(bary_interp_vector_3(q1_mat, t_nodes, t)', a_fun(t)');
B_stab1 = @(t) qmult_3(a_fun(t)', bary_interp_vector_3(q1_mat, t_nodes, t)');
M_A1 = compute_monodromy_3(T_period, A_stab1, 'L');
M_B1 = compute_monodromy_3(T_period, B_stab1, 'R');
rho1 = max(abs(eig(M_A1))) * max(abs(eig(M_B1)));

% --- Analyze Orbit 2 ---
A_stab2 = @(t) qmult_3(bary_interp_vector_3(q2_mat, t_nodes, t)', a_fun(t)');
B_stab2 = @(t) qmult_3(a_fun(t)', bary_interp_vector_3(q2_mat, t_nodes, t)');
M_A2 = compute_monodromy_3(T_period, A_stab2, 'L');
M_B2 = compute_monodromy_3(T_period, B_stab2, 'R');
rho2 = max(abs(eig(M_A2))) * max(abs(eig(M_B2)));

% --- Print actual results ---
fprintf('------------------------------------------------\n');
fprintf('Orbit 1 Spectral Radius: %.4f  =>  %s\n', rho1, get_status_3(rho1));
fprintf('Orbit 2 Spectral Radius: %.4f  =>  %s\n', rho2, get_status_3(rho2));
fprintf('------------------------------------------------\n');

fprintf('\n=== Table 5.3: Residual Verification of Periodic Solutions ===\n');
calc_internal_res = @(Q) compute_internal_residual_3(Q, D_global, t_nodes, a_fun, c_fun);
res_internal1 = calc_internal_res(Q_sol1);
res_internal2 = calc_internal_res(Q_sol2);
fprintf('--------------------------------------------------------------------------\n');
fprintf('| %-8s | %-15s | %-18s |\n', 'Orbit', 'Stability', 'Internal Res');
fprintf('|----------|-----------------|--------------------|\n');
fprintf('| %-8s | %-15s | %-18.4e |\n', 'Orbit 1', get_status_3(rho1), res_internal1);
fprintf('| %-8s | %-15s | %-18.4e |\n', 'Orbit 2', get_status_3(rho2), res_internal2);
fprintf('--------------------------------------------------------------------------\n');

fprintf('[Visualization] Generating Figure 5.3 (3D Phase Portrait)...\n');
t_fine = linspace(0, T_period, 1000);
q1_fine = bary_interp_vector_3(q1_mat, t_nodes, t_fine);
q2_fine = bary_interp_vector_3(q2_mat, t_nodes, t_fine);

fig3 = figure('Position', [100, 100, 900, 700], 'Color', 'w');
ax3 = axes('Position', [0.1, 0.1, 0.85, 0.85]);
hold(ax3, 'on'); grid(ax3, 'on'); 

% --- Dynamic legend names ---
if rho1 < 1 - 1e-4, status1_str = '< 1 (Stable)'; else, status1_str = '> 1 (Unstable)'; end
name1 = sprintf('Orbit 1 ($\\rho \\approx %.2f %s$)', rho1, status1_str);
if rho2 < 1 - 1e-4, status2_str = '< 1 (Stable)'; else, status2_str = '> 1 (Unstable)'; end
name2 = sprintf('Orbit 2 ($\\rho \\approx %.2f %s$)', rho2, status2_str);

% --- Plot main orbits ---
p1 = plot3(q1_fine(:,2), q1_fine(:,3), q1_fine(:,4), '-', 'Color', [colors.blue, 0.9], 'LineWidth', 2.5, 'DisplayName', name1);
p2 = plot3(q2_fine(:,2), q2_fine(:,3), q2_fine(:,4), '-', 'Color', [colors.red, 0.9], 'LineWidth', 2.5, 'DisplayName', name2);

% --- Mark start points ---
plot3(q1_fine(1,2), q1_fine(1,3), q1_fine(1,4), 'o', 'MarkerSize', 10, 'MarkerFaceColor', colors.purple, 'MarkerEdgeColor', 'w', 'LineWidth', 1.5, 'HandleVisibility', 'off');
text(q1_fine(1,2), q1_fine(1,3), q1_fine(1,4), ' $t=0$', 'Color', colors.purple, 'FontSize', 14, 'Interpreter', 'latex', 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left', 'FontWeight', 'bold');
plot3(q2_fine(1,2), q2_fine(1,3), q2_fine(1,4), 's', 'MarkerSize', 10, 'MarkerFaceColor', colors.green, 'MarkerEdgeColor', 'w', 'LineWidth', 1.5, 'HandleVisibility', 'off');
text(q2_fine(1,2), q2_fine(1,3), q2_fine(1,4), ' $t=0$', 'Color', colors.green, 'FontSize', 14, 'Interpreter', 'latex', 'VerticalAlignment', 'top', 'HorizontalAlignment', 'right', 'FontWeight', 'bold');

% --- Add arrows ---
arrow_indices = round(linspace(1, 1000, 5)); 
arrow_indices = arrow_indices(2:4); 
add_flow_arrows_fixed_3(ax3, q1_fine, arrow_indices, colors.purple, 0.1);
add_flow_arrows_fixed_3(ax3, q2_fine, arrow_indices, colors.green, 0.1);

% --- Viewpoint and decoration (SHADOW COMPLETELY REMOVED) ---
view(45, 30); 
xlabel('$q_1 (\mathbf{i})$'); ylabel('$q_2 (\mathbf{j})$'); zlabel('$q_3 (\mathbf{k})$');
title('\textbf{Figure 5.3. Topological Structure of Periodic Orbits}');
legend([p1, p2], 'Location', 'NorthEast', 'FontSize', 12, 'Interpreter', 'latex');
axis tight;
exportgraphics(fig3, 'Figure_5_3_Topology.png', 'BackgroundColor', 'white', 'Resolution', 600);

% =========================================================================

fig4 = figure('Position', [1050, 100, 600, 500], 'Color', 'w');
ax4 = axes('Position', [0.15, 0.15, 0.75, 0.75]);
hold(ax4, 'on'); axis(ax4, 'equal'); box(ax4, 'on');
theta = linspace(0, 2*pi, 300);
fill(cos(theta), sin(theta), [0.96 0.96 0.96], 'EdgeColor', 'k', 'LineStyle', '--');
eigs1 = kron(eig(M_A1), eig(M_B1));
eigs2 = kron(eig(M_A2), eig(M_B2));
h_s = plot(real(eigs1), imag(eigs1), 'o', 'MarkerSize', 10, 'MarkerFaceColor', colors.blue, 'MarkerEdgeColor', 'k', 'DisplayName', 'Multipliers of Orbit 1');
h_u = plot(real(eigs2), imag(eigs2), 's', 'MarkerSize', 10, 'MarkerFaceColor', colors.red, 'MarkerEdgeColor', 'k', 'DisplayName', 'Multipliers of Orbit 2');
xlabel('Re($\lambda$)'); ylabel('Im($\lambda$)');
title('\textbf{Figure 5.4. Bilateral Floquet Spectrum}');
legend([h_s, h_u], 'Location', 'NorthEast'); 
grid on;
max_eig_norm = max([abs(eigs1); abs(eigs2); 1.2]);
axis_lim = max_eig_norm * 1.2; 
xlim([-axis_lim, axis_lim]); ylim([-axis_lim, axis_lim]);
if rho1 < 1 - 1e-4, status1_str = '< 1 \textbf{(Stable)}'; else, status1_str = '> 1 \textbf{(Unstable)}'; end
text(1, -2.5, sprintf('$\\rho_1 \\approx %.4f %s$', rho1, status1_str), 'Color', colors.blue, 'FontSize', 14, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', 'Interpreter', 'latex', 'BackgroundColor', 'w', 'EdgeColor', 'none');
if rho2 < 1 - 1e-4, status2_str = '< 1 \textbf{(Stable)}'; else, status2_str = '> 1 \textbf{(Unstable)}'; end
text(0, axis_lim * 0.85, sprintf('$\\rho_2 \\approx %.4f %s$', rho2, status2_str), 'Color', colors.red, 'FontSize', 14, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', 'Interpreter', 'latex', 'BackgroundColor', 'w', 'EdgeColor', 'none');
text(0, -axis_lim * 0.85, sprintf('$\\rho_1 \\approx %.4f %s$', rho1, status1_str), 'Color', colors.blue, 'FontSize', 14, 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', 'Interpreter', 'latex', 'BackgroundColor', 'w', 'EdgeColor', 'none');
exportgraphics(fig4, 'Figure_5_4_Spectrum.png', 'BackgroundColor', 'white', 'Resolution', 600);

% =========================================================================

fprintf('[Visualization] Generating Figure 5.5 (Perturbation Evolution)...\n');
fig5 = figure('Position', [150, 150, 1000, 500], 'Color', 'w');
% --- Subplot 1 ---
subplot(1, 2, 1); hold on; grid on; box on;
title('\textbf{(a) Stable Orbit Perturbation}', 'Interpreter', 'latex');
xlabel('$q_1$'); ylabel('$q_2$'); zlabel('$q_3$'); view(3);
plot3(q1_fine(:,2), q1_fine(:,3), q1_fine(:,4), 'k-', 'LineWidth', 2, 'DisplayName', 'Limit Cycle');
perturbation_scale = 0.05; num_perturbations = 8; t_span_pert = [0, T_period];
for k = 1:num_perturbations
    q0_pert = q1_mat(1,:)' + perturbation_scale * (rand(4,1)-0.5);
    [~, Y_pert] = ode45(@(t,y) riccati_rhs_3(t,y,a_fun,c_fun), t_span_pert, q0_pert);
    plot3(Y_pert(:,2), Y_pert(:,3), Y_pert(:,4), '-', 'Color', [colors.blue, 0.6], 'LineWidth', 1);
end
% --- Subplot 2 ---
subplot(1, 2, 2); hold on; grid on; box on;
title('\textbf{(b) Unstable Orbit Perturbation}', 'Interpreter', 'latex');
xlabel('$q_1$'); ylabel('$q_2$'); zlabel('$q_3$'); view(3);
plot3(q2_fine(:,2), q2_fine(:,3), q2_fine(:,4), 'k-', 'LineWidth', 2, 'DisplayName', 'Limit Cycle');
t_span_pert_unstable = [0, 30*T_period]; 
for k = 1:num_perturbations
    q0_pert = q2_mat(1,:)' + perturbation_scale * (rand(4,1)-0.5);
    [~, Y_pert] = ode45(@(t,y) riccati_rhs_3(t,y,a_fun,c_fun), t_span_pert_unstable, q0_pert);
    plot3(Y_pert(:,2), Y_pert(:,3), Y_pert(:,4), '-', 'Color', [colors.red, 0.6], 'LineWidth', 1);
end
exportgraphics(fig5, 'Figure_5_5_Perturbation.png', 'BackgroundColor', 'white', 'Resolution', 600);

% =========================================================================

fprintf('\n=== Step 6: Comparative Analysis (Q-CSCM vs. Q-LSCM vs. Explicit & Implicit RK4 Shooting) ===\n');
fprintf('Generating Ground Truth (N=100)...\n');
N_truth = 100; [x_true, D_true] = cheb_3(N_truth); t_true = (x_true + 1) * T_period / 2; D_glob_true = kron(D_true * dt_dtau, eye(4));
q_guess_true = reshape(bary_interp_vector_3(q1_mat, t_nodes, t_true)', [], 1);
[Q_true_sol, conv_true] = newton_solver_robust_3(q_guess_true, D_glob_true, t_true, a_fun, c_fun);
q0_exact = Q_true_sol(1:4); 

fprintf('Testing Q-CSCM (Chebyshev) convergence...\n');
N_list = 8:4:100; 
err_cscm = zeros(size(N_list)); dof_cscm = zeros(size(N_list));
for k = 1:length(N_list)
    n_k = N_list(k); [x_k, D_k] = cheb_3(n_k); t_k = (x_k + 1) * T_period / 2; D_glob_k = kron(D_k * dt_dtau, eye(4));
    q_guess_k = reshape(bary_interp_vector_3(q1_mat, t_nodes, t_k)', [], 1);
    [Q_k, conv_k] = newton_solver_robust_3(q_guess_k, D_glob_k, t_k, a_fun, c_fun);
    if conv_k, err_cscm(k) = norm(Q_k(1:4) - q0_exact); dof_cscm(k) = 4 * (n_k + 1); else, err_cscm(k) = NaN; end
end

fprintf('Testing Q-LSCM (Legendre) convergence...\n');
err_lscm = zeros(size(N_list)); dof_lscm = zeros(size(N_list));
for k = 1:length(N_list)
    n_k = N_list(k); [x_k, D_k] = leg_D_3(n_k); t_k = (x_k + 1) * T_period / 2; D_glob_k = kron(D_k * dt_dtau, eye(4));
    q_guess_k = reshape(bary_interp_vector_3(q1_mat, t_nodes, t_k)', [], 1);
    [Q_k, conv_k] = newton_solver_robust_3(q_guess_k, D_glob_k, t_k, a_fun, c_fun);
    if conv_k, err_lscm(k) = norm(Q_k(1:4) - q0_exact); dof_lscm(k) = 4 * (n_k + 1); else, err_lscm(k) = NaN; end
end

fprintf('Testing Explicit ERK4 and Implicit GL-IRK4 Shooting convergence...\n');
M_list = 100:50:1000; err_erk4 = zeros(size(M_list)); dof_erk4 = zeros(size(M_list)); err_glirk4 = zeros(size(M_list)); dof_glirk4 = zeros(size(M_list));
options = optimoptions('fsolve', 'Display', 'off', 'TolFun', 1e-14, 'TolX', 1e-14, 'MaxFunctionEvaluations', 20000);
for k = 1:length(M_list)
    steps = M_list(k);
    % ERK4
    shooting_fun_erk4 = @(q0) rk4_integrator_3(q0, T_period, steps, a_fun, c_fun) - q0;
    [q0_erk4, ~, exitflag_erk] = fsolve(shooting_fun_erk4, q0_exact, options);
    if exitflag_erk > 0, err_erk4(k) = norm(q0_erk4 - q0_exact); dof_erk4(k) = 4 * steps; else, err_erk4(k) = NaN; end
    % GL-IRK4
    shooting_fun_glirk4 = @(q0) gl_irk4_integrator_3(q0, T_period, steps, a_fun, c_fun) - q0;
    [q0_glirk4, ~, exitflag_gl] = fsolve(shooting_fun_glirk4, q0_exact, options);
    if exitflag_gl > 0, err_glirk4(k) = norm(q0_glirk4 - q0_exact); dof_glirk4(k) = 4 * steps; else, err_glirk4(k) = NaN; end
end


fig6 = figure('Position', [200, 200, 800, 550], 'Color', 'w');
ax6 = axes('Position', [0.12, 0.15, 0.82, 0.75]);

% 1. Chebyshev (Blue)
loglog(ax6, dof_cscm, err_cscm + 1e-16, '-o', 'Color', '#0072BD', ...
    'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', '#0072BD', 'MarkerEdgeColor', 'w'); 
hold(ax6, 'on'); 

% 2. Legendre (Purple)
loglog(ax6, dof_lscm, err_lscm + 1e-16, '-.d', 'Color', '#7E2F8E', ...
    'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', '#7E2F8E', 'MarkerEdgeColor', 'w'); 

% 3. ERK4 (Orange)
loglog(ax6, dof_erk4, err_erk4 + 1e-16, '--s', 'Color', '#D95319', ...
    'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', '#D95319', 'MarkerEdgeColor', 'w');

% 4. GL-IRK4 (Green)
loglog(ax6, dof_glirk4, err_glirk4 + 1e-16, '-.^', 'Color', '#77AC30', ...
    'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', '#77AC30', 'MarkerEdgeColor', 'w');

set(ax6, 'XScale', 'log', 'YScale', 'log');
xlim(ax6, [10, 10000]); 
ylim(ax6, [1e-16, 1e1]);

x_tick_pos = 10.^(1 : 0.125 : 4); 
set(ax6, 'XTick', x_tick_pos);

x_labels = cell(1, length(x_tick_pos));
for i = 1:length(x_tick_pos)
    val = log10(x_tick_pos(i));
    if abs(val - round(val)) < 1e-9  
        x_labels{i} = sprintf('$10^{%d}$', round(val));
    else
        x_labels{i} = '';
    end
end
set(ax6, 'XTickLabel', x_labels, 'TickLabelInterpreter', 'latex');

y_tick_pos = 10.^(-16:0);
set(ax6, 'YTick', y_tick_pos);
y_labels = cell(1, length(y_tick_pos));
for i = 1:length(y_tick_pos)
    val = -16 + i - 1;
    if mod(val, 4) == 0
        y_labels{i} = sprintf('$10^{%d}$', val);
    else
        y_labels{i} = '';
    end
end
set(ax6, 'YTickLabel', y_labels);

grid(ax6, 'on');
set(ax6, 'XMinorGrid', 'off', 'YMinorGrid', 'off'); 
set(ax6, 'XMinorTick', 'off', 'YMinorTick', 'off');

set(ax6, 'GridLineStyle', ':', 'GridColor', [0.8 0.8 0.8], 'GridAlpha', 0.6);
box(ax6, 'on'); 
set(ax6, 'LineWidth', 1.2, 'FontSize', 12, 'FontName', 'Times New Roman');

xlabel(ax6, 'Degrees of Freedom ($N$ or Steps)', 'Interpreter', 'latex', 'FontSize', 14); 
ylabel(ax6, 'Shooting Error $\|q_0 - q_{\mathrm{exact}}\|$', 'Interpreter', 'latex', 'FontSize', 14);
title('\textbf{Figure 5.7. Convergence Comparison (Nonlinear Riccati)}', 'Interpreter', 'latex', 'FontSize', 15);

leg = legend({'Proposed Q-CSCM (Chebyshev)', 'Proposed Q-LSCM (Legendre)', 'Explicit RK4 Shooting ($\mathcal{O}(h^4)$)', 'Implicit GL-IRK4 Shooting ($\mathcal{O}(h^4)$)'}, ...
    'Location', 'SouthWest', 'Interpreter', 'latex', 'FontSize', 11, 'AutoUpdate', 'off');
leg.EdgeColor = [0.9 0.9 0.9]; 

text(25, 1e-12, '\textbf{Spectral Convergence}', 'Color', '#0072BD', 'Interpreter', 'latex', 'FontSize', 13);
text(1200, 1e-8, '\textbf{Algebraic Decay}', 'Color', '#77AC30', 'Interpreter', 'latex', 'FontSize', 13);

exportgraphics(fig6, 'Figure_5_7_Convergence.png', 'BackgroundColor', 'white', 'Resolution', 600);

