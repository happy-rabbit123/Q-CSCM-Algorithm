function q_out = qmult_vec_5(q1, q2)
    % q1, q2: Nx4 matrices
    % q_out: Nx4 matrix
    
    s1 = q1(:,1); v1 = q1(:,2:4);
    s2 = q2(:,1); v2 = q2(:,2:4);
    
    s = s1.*s2 - dot(v1, v2, 2);
    v = s1.*v2 + s2.*v1 + cross(v1, v2, 2);
    
    q_out = [s, v];
end