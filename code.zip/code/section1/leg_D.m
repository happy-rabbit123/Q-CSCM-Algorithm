function [D, x] = leg_D(N)
    % Compute Legendre-Gauss-Lobatto nodes and differentiation matrix
    x = cos(pi*(0:N)/N)'; % Initial guess
    P = zeros(N+1, N+1);
    xold = 2;
    while max(abs(x - xold)) > eps
        xold = x; P(:,1) = 1; P(:,2) = x;
        for k = 2:N
            P(:,k+1) = ((2*k-1)*x.*P(:,k) - (k-1)*P(:,k-1))/k;
        end
        x = xold - (x.*P(:,N+1) - P(:,N))./(N*P(:,N+1));
    end
    w = 2./(N*(N+1)*P(:,N+1).^2);
    c = P(:,N+1);
    X = repmat(x, 1, N+1);
    dX = X - X';
    D = (c*(1./c)') ./ (dX + eye(N+1));
    D = D - diag(sum(D,2));
end
