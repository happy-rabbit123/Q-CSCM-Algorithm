function P_vals = leg_poly(N, x)
    % Evaluate Legendre polynomials P_0(x) to P_N(x) at a single point x
    P_vals = zeros(1, N+1);
    P_vals(1) = 1;
    if N >= 1
        P_vals(2) = x;
        for k = 2:N
            P_vals(k+1) = ((2*k-1)*x*P_vals(k) - (k-1)*P_vals(k-1))/k;
        end
    end
end