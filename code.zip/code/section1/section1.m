clear; clc; close all;

%% 1. Mathematical Problem Definition
t_span = [-1, 1];
q_exact = @(t) [exp(sin(pi*t)); cos(t); cos(5*t); 1./(1+t.^2)];
dq_exact = @(t) [pi*cos(pi*t).*exp(sin(pi*t)); -sin(t); -5*sin(5*t); -2*t./((1+t.^2).^2)];

A_mat = @(t) [-0.5; cos(t); sin(t); 0];
B_mat = @(t) [-0.2; 0; cos(2*t); sin(2*t)];

f_source = @(t) dq_exact(t) - quat_mult(A_mat(t), q_exact(t)) - quat_mult(q_exact(t), B_mat(t));
M_op = @(t) quat_L(A_mat(t)) + quat_R(B_mat(t));

%% 2. Global Convergence Tests
N_list = [4, 8, 12, 16, 20, 24, 28, 32];
steps_list = [10, 50, 100, 500, 1000, 5000];

err_Cheb = zeros(length(N_list), 1); time_Cheb = zeros(length(N_list), 1);
err_Leg  = zeros(length(N_list), 1); time_Leg  = zeros(length(N_list), 1);
err_ERK4 = zeros(length(steps_list), 1); time_ERK4 = zeros(length(steps_list), 1);
err_GLIRK4 = zeros(length(steps_list), 1); time_GLIRK4 = zeros(length(steps_list), 1);

fprintf('--- Running Global Convergence Tests ---\n');

% ==================== 2.1 Run Chebyshev & Legendre ====================
for idx = 1:length(N_list)
    N = N_list(idx); 
    
    % --- Chebyshev ---
    tic; [D_C, x_C] = cheb(N); 
    D_g_C = kron(D_C, eye(4)); M_g_C = zeros(4*(N+1), 4*(N+1)); F_g_C = zeros(4*(N+1), 1);
    for i = 1:(N+1)
        idx_r = 4*(i-1)+1 : 4*i; M_g_C(idx_r, idx_r) = M_op(x_C(i)); F_g_C(idx_r) = f_source(x_C(i));
    end
    LHS_C = D_g_C - M_g_C; RHS_C = F_g_C;
    LHS_C(end-3:end, :) = 0; LHS_C(end-3:end, end-3:end) = eye(4); RHS_C(end-3:end) = q_exact(-1);
    Q_num_C = LHS_C \ RHS_C; time_Cheb(idx) = toc;
    
    Q_ex_C = zeros(4*(N+1), 1); for i=1:(N+1), Q_ex_C(4*(i-1)+1 : 4*i) = q_exact(x_C(i)); end
    err_Cheb(idx) = max(abs(Q_num_C - Q_ex_C)); 
    
    % --- Legendre ---
    tic; [D_L, x_L] = leg_D(N); 
    D_g_L = kron(D_L, eye(4)); M_g_L = zeros(4*(N+1), 4*(N+1)); F_g_L = zeros(4*(N+1), 1);
    for i = 1:(N+1)
        idx_r = 4*(i-1)+1 : 4*i; M_g_L(idx_r, idx_r) = M_op(x_L(i)); F_g_L(idx_r) = f_source(x_L(i));
    end
    LHS_L = D_g_L - M_g_L; RHS_L = F_g_L;
    LHS_L(end-3:end, :) = 0; LHS_L(end-3:end, end-3:end) = eye(4); RHS_L(end-3:end) = q_exact(-1);
    Q_num_L = LHS_L \ RHS_L; time_Leg(idx) = toc;
    
    Q_ex_L = zeros(4*(N+1), 1); for i=1:(N+1), Q_ex_L(4*(i-1)+1 : 4*i) = q_exact(x_L(i)); end
    err_Leg(idx) = max(abs(Q_num_L - Q_ex_L)); 
end

% ==================== 2.2 Run Baselines (ERK4 & GL-IRK4) ====================
c1 = 0.5 - sqrt(3)/6; c2 = 0.5 + sqrt(3)/6;
a11 = 0.25; a12 = 0.25 - sqrt(3)/6; a21 = 0.25 + sqrt(3)/6; a22 = 0.25; b1 = 0.5; b2 = 0.5;

for idx = 1:length(steps_list)
    steps = steps_list(idx); h = 2 / steps; t_grid = linspace(-1, 1, steps+1);
    % ERK4
    tic; q_erk = zeros(4, steps+1); q_erk(:, 1) = q_exact(-1);
    for n = 1:steps
        tn = t_grid(n); qn = q_erk(:, n); k1 = M_op(tn)*qn + f_source(tn);
        k2 = M_op(tn + h/2)*(qn + h/2*k1) + f_source(tn + h/2); k3 = M_op(tn + h/2)*(qn + h/2*k2) + f_source(tn + h/2);
        k4 = M_op(tn + h)*(qn + h*k3) + f_source(tn + h); q_erk(:, n+1) = qn + (h/6)*(k1 + 2*k2 + 2*k3 + k4);
    end
    time_ERK4(idx) = toc;
    
    % GL-IRK4
    tic; q_gl = zeros(4, steps+1); q_gl(:, 1) = q_exact(-1);
    for n = 1:steps
        tn = t_grid(n); qn = q_gl(:, n); M1 = M_op(tn + c1*h); f1 = f_source(tn + c1*h); M2 = M_op(tn + c2*h); f2 = f_source(tn + c2*h);
        Sys_Mat = [eye(4) - h*a11*M1, -h*a12*M1; -h*a21*M2, eye(4) - h*a22*M2];
        K_vec = Sys_Mat \ [M1*qn + f1; M2*qn + f2]; q_gl(:, n+1) = qn + h*(b1*K_vec(1:4) + b2*K_vec(5:8));
    end
    time_GLIRK4(idx) = toc;
    
    q_ex_grid = zeros(4, steps+1); for i=1:steps+1, q_ex_grid(:, i) = q_exact(t_grid(i)); end
    err_ERK4(idx) = max(abs(q_erk(:) - q_ex_grid(:))); err_GLIRK4(idx) = max(abs(q_gl(:) - q_ex_grid(:)));
end

%% 3. Detailed Pointwise Error & Spectral Decay (N=40)
fprintf('--- Running Detailed Pointwise & Spectral Analysis ---\n');
N_fixed = 40; steps_fixed = 1000; h_f = 2/steps_fixed;

% --- 3.1 Chebyshev (N=40) ---
[D_C, t_cs] = cheb(N_fixed); D_g = kron(D_C, eye(4)); M_g = zeros(4*(N_fixed+1), 4*(N_fixed+1)); F_g = zeros(4*(N_fixed+1), 1);
for i=1:N_fixed+1, idx_r = 4*(i-1)+1 : 4*i; M_g(idx_r, idx_r) = M_op(t_cs(i)); F_g(idx_r) = f_source(t_cs(i)); end
LHS = D_g - M_g; RHS = F_g; LHS(end-3:end, :) = 0; LHS(end-3:end, end-3:end) = eye(4); RHS(end-3:end) = q_exact(-1);
Q_num_fixed_C = LHS \ RHS; Q_exact_cs = zeros(4, N_fixed+1); Q_res_cs = zeros(4, N_fixed+1);
for i=1:N_fixed+1, Q_res_cs(:, i) = Q_num_fixed_C(4*(i-1)+1 : 4*i); Q_exact_cs(:, i) = q_exact(t_cs(i)); end
pointwise_err_Cheb = sqrt(sum((Q_res_cs - Q_exact_cs).^2, 1));

% Chebyshev Coefficients
coeff_matrix_C = zeros(4, N_fixed+1); c_bar = ones(N_fixed+1, 1); c_bar(1) = 2; c_bar(end) = 2;
for k = 0:N_fixed
    T_k = cos(k * acos(t_cs)); 
    for dim = 1:4, coeff_matrix_C(dim, k+1) = (2 / (N_fixed * c_bar(k+1))) * sum( (1./c_bar) .* Q_res_cs(dim,:)' .* T_k ); end
end
spectral_amplitudes_Cheb = sqrt(sum(coeff_matrix_C.^2, 1)); 

% --- 3.2 Legendre (N=40) ---
[D_L, t_ls] = leg_D(N_fixed); D_g = kron(D_L, eye(4)); M_g = zeros(4*(N_fixed+1), 4*(N_fixed+1)); F_g = zeros(4*(N_fixed+1), 1);
for i=1:N_fixed+1, idx_r = 4*(i-1)+1 : 4*i; M_g(idx_r, idx_r) = M_op(t_ls(i)); F_g(idx_r) = f_source(t_ls(i)); end
LHS = D_g - M_g; RHS = F_g; LHS(end-3:end, :) = 0; LHS(end-3:end, end-3:end) = eye(4); RHS(end-3:end) = q_exact(-1);
Q_num_fixed_L = LHS \ RHS; Q_exact_ls = zeros(4, N_fixed+1); Q_res_ls = zeros(4, N_fixed+1);
for i=1:N_fixed+1, Q_res_ls(:, i) = Q_num_fixed_L(4*(i-1)+1 : 4*i); Q_exact_ls(:, i) = q_exact(t_ls(i)); end
pointwise_err_Leg = sqrt(sum((Q_res_ls - Q_exact_ls).^2, 1));

% Legendre Coefficients (using discrete orthogonality of Legendre polynomials)
% Need Legendre polynomials evaluated at LGL nodes
P_mat = zeros(N_fixed+1, N_fixed+1); % P_mat(i, k) is P_{k-1}(t_ls(i))
for i = 1:N_fixed+1
    P_mat(i,:) = leg_poly(N_fixed, t_ls(i)); 
end
% Integration weights for LGL nodes
w_LGL = zeros(N_fixed+1, 1);
for i = 1:N_fixed+1
    w_LGL(i) = 2 / (N_fixed*(N_fixed+1)*P_mat(i, N_fixed+1)^2);
end

coeff_matrix_L = zeros(4, N_fixed+1);
for k = 0:N_fixed
    norm_factor = 2 / (2*k + 1); % continuous norm ||P_k||^2
    if k == N_fixed, norm_factor = 2/N_fixed; end % Special case for highest mode in LGL
    for dim = 1:4
        % Discrete inner product: sum( w_i * f(x_i) * P_k(x_i) )
        sum_val = sum( w_LGL .* Q_res_ls(dim,:)' .* P_mat(:, k+1) );
        coeff_matrix_L(dim, k+1) = sum_val / norm_factor;
    end
end
spectral_amplitudes_Leg = sqrt(sum(coeff_matrix_L.^2, 1)); 

% --- 3.3 GL-IRK4 (Steps=1000) ---
t_rk = linspace(-1, 1, steps_fixed+1); q_gl_f = zeros(4, steps_fixed+1); q_gl_f(:, 1) = q_exact(-1);
for n = 1:steps_fixed
    tn = t_rk(n); qn = q_gl_f(:, n); M1 = M_op(tn + c1*h_f); f1 = f_source(tn + c1*h_f); M2 = M_op(tn + c2*h_f); f2 = f_source(tn + c2*h_f);
    K_vec = [eye(4) - h_f*a11*M1, -h_f*a12*M1; -h_f*a21*M2, eye(4) - h_f*a22*M2] \ [M1*qn + f1; M2*qn + f2];
    q_gl_f(:, n+1) = qn + h_f*(b1*K_vec(1:4) + b2*K_vec(5:8));
end
Q_exact_rk = zeros(4, steps_fixed+1); for i=1:steps_fixed+1, Q_exact_rk(:,i) = q_exact(t_rk(i)); end
pointwise_err_GL = sqrt(sum((q_gl_f - Q_exact_rk).^2, 1));

%% 4. Print LaTeX Tables to Command Window
fprintf('\n========================================================================\n');
fprintf('=== TABLE 1: Convergence of RK4 and GL-IRK4 (Copy to LaTeX) ===\n');
fprintf('========================================================================\n');
fprintf('Steps & ERK4 Error & GL-IRK4 Error & GL-IRK4 Time(s) & GL-IRK4 EOC \\\\\n');
fprintf('\\midrule\n');
for i = 1:length(steps_list)
    if i == 1
        eoc = NaN;
    else
        eoc = log10(err_GLIRK4(i-1) / err_GLIRK4(i)) / log10(steps_list(i) / steps_list(i-1));
    end
    if isnan(eoc)
        fprintf('%-5d & %-10.4e & %-13.4e & %-15.4f & %-10s \\\\\n', steps_list(i), err_ERK4(i), err_GLIRK4(i), time_GLIRK4(i), '-');
    else
        fprintf('%-5d & %-10.4e & %-13.4e & %-15.4f & %-10.2f \\\\\n', steps_list(i), err_ERK4(i), err_GLIRK4(i), time_GLIRK4(i), eoc);
    end
end

fprintf('\n============================================================================================\n');
fprintf('=== TABLE 2: Spectral Accuracy Comparison: Q-CSCM vs Q-LSCM (Copy to LaTeX) ===\n');
fprintf('============================================================================================\n');
fprintf('N  & Q-LSCM (Legendre) & Q-CSCM (Chebyshev) & LSCM Time(s) & CSCM Time(s) \\\\\n');
fprintf('\\midrule\n');
for i = 1:length(N_list)
    fprintf('%-2d & %-18.4e & %-18.4e & %-12.4f & %-12.4f \\\\\n', ...
            N_list(i), err_Leg(i), err_Cheb(i), time_Leg(i), time_Cheb(i));
end
fprintf('============================================================================================\n\n');

%% 5. Generate SCI-Standard Composite Figure
figure('Units', 'pixels', 'Position', [50, 50, 1400, 850], 'Color', 'w');
tlo = tiledlayout(2, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
c_cheb = '#0072BD'; c_leg = '#7E2F8E'; c_exp = '#D95319'; c_imp = '#77AC30'; 
grid_alpha = 0.1; 

% --- Tile 1 (a): Convergence ---
nexttile(1);
loglog(N_list, err_Cheb, '-o', 'LineWidth', 2, 'MarkerSize', 7, 'Color', c_cheb, 'MarkerFaceColor', c_cheb); hold on;
loglog(N_list, err_Leg, '-.d', 'LineWidth', 2, 'MarkerSize', 6, 'Color', c_leg, 'MarkerFaceColor', c_leg);
loglog(steps_list, err_ERK4, '--s', 'LineWidth', 2, 'MarkerSize', 6, 'Color', c_exp);
loglog(steps_list, err_GLIRK4, '-.^', 'LineWidth', 2, 'MarkerSize', 6, 'Color', c_imp);
patch([500, 1000, 1000], [err_GLIRK4(4), err_GLIRK4(4), err_GLIRK4(4)/16], [0.7 0.7 0.7], 'FaceAlpha', 0.2, 'EdgeColor', 'none'); % 稍微调浅了三角形背景
text(600, err_GLIRK4(4)*3, '$\mathcal{O}(h^4)$', 'Interpreter', 'latex', 'FontSize', 12);
grid on; set(gca, 'GridAlpha', grid_alpha, 'MinorGridAlpha', grid_alpha, 'FontSize', 11, 'FontName', 'Times New Roman');
xlabel('Degrees of Freedom ($N$ or Steps)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Global Error $\|q_{num} - q_{exact}\|_\infty$', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{(a) Spectral vs. Algebraic Convergence}', 'Interpreter', 'latex', 'FontSize', 13);
legend({'Chebyshev Spectral (Proposed)', 'Legendre Spectral', 'Explicit RK4', 'Implicit GL-IRK4'}, 'Interpreter', 'latex', 'Location', 'southwest', 'FontSize', 10);
ylim([1e-15, 1e2]);

% --- Tile 2 (b): Efficiency ---
nexttile(2);
loglog(time_Cheb, err_Cheb, '-o', 'LineWidth', 2, 'MarkerSize', 7, 'Color', c_cheb, 'MarkerFaceColor', c_cheb); hold on;
loglog(time_Leg, err_Leg, '-.d', 'LineWidth', 2, 'MarkerSize', 6, 'Color', c_leg, 'MarkerFaceColor', c_leg);
loglog(time_ERK4, err_ERK4, '--s', 'LineWidth', 2, 'MarkerSize', 6, 'Color', c_exp);
loglog(time_GLIRK4, err_GLIRK4, '-.^', 'LineWidth', 2, 'MarkerSize', 6, 'Color', c_imp);
grid on; set(gca, 'GridAlpha', grid_alpha, 'MinorGridAlpha', grid_alpha, 'FontSize', 11, 'FontName', 'Times New Roman');
xlabel('CPU Time (seconds)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Global Error', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{(b) Computational Efficiency Trade-off}', 'Interpreter', 'latex', 'FontSize', 13);
legend({'Chebyshev', 'Legendre', 'Explicit RK4', 'Implicit GL-IRK4'}, 'Interpreter', 'latex', 'Location', 'northeast', 'FontSize', 10);
ylim([1e-15, 1e2]); xlim([1e-4, 1e0]);

% --- Tile 3 (c): Pointwise Error ---
nexttile(3);
semilogy(t_rk, pointwise_err_GL, '-.', 'LineWidth', 1.5, 'Color', c_imp); hold on;
semilogy(t_ls, pointwise_err_Leg, '-.', 'LineWidth', 2, 'Color', c_leg);
semilogy(t_cs, pointwise_err_Cheb, '-', 'LineWidth', 2, 'Color', c_cheb); 
grid on; set(gca, 'GridAlpha', grid_alpha, 'MinorGridAlpha', grid_alpha, 'FontSize', 11, 'FontName', 'Times New Roman');
xlabel('Time $t$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Pointwise Norm $\|q(t) - q_{ex}(t)\|$', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{(c) Pointwise Error Evolution}', 'Interpreter', 'latex', 'FontSize', 13);
legend({sprintf('GL-IRK4 (Steps=%d)', steps_fixed), sprintf('Legendre ($N$=%d)', N_fixed), sprintf('Chebyshev ($N$=%d)', N_fixed)}, 'Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 10);
ylim([1e-16, 1e-4]); xlim([-1, 1]);

% --- Tile 4 (d): Spectral Decay ---
nexttile(4);
modes = 0:N_fixed;
semilogy(modes, spectral_amplitudes_Cheb, '-s', 'LineWidth', 1.5, 'MarkerSize', 4, 'Color', c_cheb, 'MarkerFaceColor', c_cheb); hold on;
semilogy(modes, spectral_amplitudes_Leg, '-.d', 'LineWidth', 1.5, 'MarkerSize', 4, 'Color', c_leg, 'MarkerFaceColor', c_leg);
plot([5, 25], [1e-2, 1e-12], 'k--', 'LineWidth', 1);
text(15, 1e-6, '$|\hat{c}_k| \sim e^{-\gamma k}$', 'Interpreter', 'latex', 'FontSize', 12, 'Rotation', -25);
grid on; set(gca, 'GridAlpha', grid_alpha, 'MinorGridAlpha', grid_alpha, 'FontSize', 11, 'FontName', 'Times New Roman');
xlabel('Mode Number $k$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Coefficient Magnitude $\|\hat{c}_k\|$', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{(d) Spectral Coefficients Decay}', 'Interpreter', 'latex', 'FontSize', 13);
legend({'Chebyshev Coeffs', 'Legendre Coeffs'}, 'Interpreter', 'latex', 'Location', 'southwest', 'FontSize', 10);
ylim([1e-16, 1e1]); xlim([0, 40]);

% --- Tile 5 (e): Dynamics ---
nexttile(5, [1, 2]); 
plot(t_rk, Q_exact_rk(1,:), 'k-', 'LineWidth', 1.5); hold on;
plot(t_rk, Q_exact_rk(2,:), 'r-.', 'LineWidth', 1.5);
plot(t_rk, Q_exact_rk(3,:), 'g--', 'LineWidth', 1.5);
plot(t_rk, Q_exact_rk(4,:), 'b:', 'LineWidth', 1.5);
grid on; set(gca, 'GridAlpha', grid_alpha, 'MinorGridAlpha', grid_alpha, 'FontSize', 11, 'FontName', 'Times New Roman');
xlabel('Time $t$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Component Value', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{(e) Dynamics of Quaternion Components (Exact Solution)}', 'Interpreter', 'latex', 'FontSize', 13);
legend({'$q_0$ (Scalar)', '$q_1$ ($\mathbf{i}$)', '$q_2$ ($\mathbf{j}$)', '$q_3$ ($\mathbf{k}$)'}, ...
    'Interpreter', 'latex', 'NumColumns', 4, 'Location', 'best', 'FontSize', 11);
xlim([-1, 1]); ylim([-1.2, 3]);

